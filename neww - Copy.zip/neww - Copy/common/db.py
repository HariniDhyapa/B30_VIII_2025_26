from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from common.config import settings

DATABASE_URL = (
    f"postgresql+psycopg2://{settings.postgres_user}:{settings.postgres_password}"
    f"@{settings.postgres_host}:{settings.postgres_port}/{settings.postgres_db}"
)

engine = create_engine(DATABASE_URL, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def set_tenant_schema(session, schema: str) -> None:
    session.execute(text(f'SET search_path TO "{schema}", public'))


def reset_schema(session) -> None:
    session.execute(text("SET search_path TO public"))
