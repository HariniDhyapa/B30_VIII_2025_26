import json
from typing import Any

import pika

from common.config import settings


def publish_event(routing_key: str, payload: dict[str, Any]) -> None:
    connection = pika.BlockingConnection(pika.URLParameters(settings.rabbitmq_url))
    channel = connection.channel()
    channel.exchange_declare(exchange="commerce", exchange_type="topic", durable=True)
    channel.basic_publish(
        exchange="commerce",
        routing_key=routing_key,
        body=json.dumps(payload).encode("utf-8"),
        properties=pika.BasicProperties(delivery_mode=2),
    )
    connection.close()
