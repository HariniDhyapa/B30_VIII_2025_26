from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    service_name: str = "service"
    api_port: int = 8000

    postgres_host: str = "postgres"
    postgres_port: int = 5432
    postgres_user: str = "postgres"
    postgres_password: str = "postgres"
    postgres_db: str = "multitenant"

    redis_url: str = "redis://redis:6379/0"
    rabbitmq_url: str = "amqp://guest:guest@rabbitmq:5672/"

    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    jwt_exp_minutes: int = 60
    provisioning_api_key: str = ""
    frontend_base_url: str = "http://localhost:3000"
    platform_admin_email: str = "admin@example.com"
    platform_admin_password: str = "Password123!"

    payment_success_rate: float = 1.0
    payment_provider: str = "mock"
    payment_service_url: str = "http://payment:8000"
    payment_internal_api_key: str = "dev-internal-payment-key"
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


settings = Settings()
