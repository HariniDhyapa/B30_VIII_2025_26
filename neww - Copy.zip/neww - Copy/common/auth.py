import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict

from jose import JWTError, jwt

from common.config import settings

_SCHEMA_RE = re.compile(r"^[a-z_][a-z0-9_]{1,62}$")


def validate_schema_name(schema: str) -> str:
    if not _SCHEMA_RE.match(schema):
        raise ValueError("Invalid schema name")
    return schema


def create_access_token(payload: Dict[str, Any], expires_minutes: int | None = None) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=expires_minutes or settings.jwt_exp_minutes)
    to_encode = {**payload, "exp": exp}
    return jwt.encode(to_encode, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_access_token(token: str) -> Dict[str, Any]:
    try:
        return jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except JWTError as exc:
        raise ValueError("Invalid token") from exc
