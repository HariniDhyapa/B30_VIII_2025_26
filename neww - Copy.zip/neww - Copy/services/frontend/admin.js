const $ = (id) => document.getElementById(id);
const state = {
  token: "",
};

function log(title, payload) {
  const stamp = new Date().toLocaleTimeString();
  const body = typeof payload === "string" ? payload : JSON.stringify(payload, null, 2);
  $("adminLog").textContent = `[${stamp}] ${title}\n${body}\n\n${$("adminLog").textContent}`;
}

function baseTenantUrl() {
  return $("tenantApi").value.trim();
}

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const text = await response.text();
  let data = text;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {}
  if (!response.ok) {
    throw new Error(typeof data === "string" ? data : JSON.stringify(data));
  }
  return data;
}

function authHeaders() {
  return state.token ? { Authorization: `Bearer ${state.token}` } : {};
}

function toTitle(value) {
  return String(value)
    .split(/[-_\s]+/)
    .filter(Boolean)
    .map((chunk) => chunk[0].toUpperCase() + chunk.slice(1))
    .join(" ");
}

function renderTenants(items = []) {
  const body = $("tenantBody");
  if (!items.length) {
    body.innerHTML = '<tr><td colspan="6" class="empty-cell">No tenants found.</td></tr>';
    return;
  }
  body.innerHTML = items
    .map((item) => {
      const storeUrl = item.storefront_domain
        ? `https://${item.storefront_domain}`
        : `http://localhost:3000/?tenant=${item.slug}`;
      return `
        <tr>
          <td>${item.name}</td>
          <td>${item.slug}</td>
          <td>${item.storefront_name || item.name}</td>
          <td>${item.schema_name}</td>
          <td><a href="${storeUrl}" target="_blank" rel="noreferrer">${storeUrl}</a></td>
          <td><button type="button" class="small-button secondary open-store" data-store-url="${storeUrl}">Open Store</button></td>
        </tr>
      `;
    })
    .join("");

  document.querySelectorAll(".open-store").forEach((button) => {
    button.addEventListener("click", () => {
      const storeUrl = button.dataset.storeUrl;
      if (!storeUrl) {
        return;
      }
      window.open(storeUrl, "_blank", "noopener,noreferrer");
    });
  });
}

async function loginAdmin(event) {
  event.preventDefault();
  const formData = new FormData(event.currentTarget);
  const payload = {
    email: String(formData.get("email") || "").trim(),
    password: String(formData.get("password") || "").trim(),
  };
  const data = await request(`${baseTenantUrl()}/platform/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  state.token = data.access_token;
  $("adminStatus").textContent = "Logged in";
  log("Admin login successful", { email: payload.email });
  await loadTenants();
}

async function loadTenants() {
  if (!state.token) {
    throw new Error("Platform admin login required.");
  }
  const data = await request(`${baseTenantUrl()}/platform/tenants`, {
    headers: authHeaders(),
  });
  renderTenants(data.items || []);
  log("Loaded tenants", { count: (data.items || []).length });
}

async function createAndOpenStore() {
  if (!state.token) {
    throw new Error("Platform admin login required.");
  }

  const slug = (window.prompt("New store slug (example: reebok-shop):", "") || "").trim().toLowerCase();
  if (!slug) {
    return;
  }
  const email = (window.prompt("Seller email:", `seller@${slug.replace(/[^a-z0-9-]/g, "")}.com`) || "").trim();
  if (!email) {
    return;
  }
  const password = (window.prompt("Seller password:", "Password123!") || "").trim();
  if (!password) {
    return;
  }

  const tenantName = toTitle(slug);
  const payload = {
    tenant_name: tenantName,
    tenant_slug: slug,
    seller_name: `${tenantName} Owner`,
    seller_email: email,
    password,
    settings: {
      storefront_name: tenantName,
      primary_color: "#111111",
      accent_color: "#eef2f7",
      currency: "INR",
      support_email: email,
      hero_title: `${tenantName} Store`,
      hero_subtitle: `Welcome to the official ${tenantName} storefront.`,
    },
    sample_products: [],
  };

  const data = await request(`${baseTenantUrl()}/platform/tenants/provision`, {
    method: "POST",
    headers: {
      ...authHeaders(),
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  log("Store created", {
    slug: data.tenant?.slug,
    storefront_url: data.delivery?.storefront_url,
    seller_login_email: data.delivery?.seller_login_email,
  });
  await loadTenants();
  if (data.delivery?.storefront_url) {
    window.open(data.delivery.storefront_url, "_blank", "noopener,noreferrer");
  }
}

function bind() {
  $("adminLoginForm").addEventListener("submit", (event) => {
    loginAdmin(event).catch((error) => log("Admin login failed", error.message));
  });
  $("refreshTenants").addEventListener("click", () => {
    loadTenants().catch((error) => log("Tenant load failed", error.message));
  });
  $("createStore").addEventListener("click", () => {
    createAndOpenStore().catch((error) => log("Create store failed", error.message));
  });
}

bind();
