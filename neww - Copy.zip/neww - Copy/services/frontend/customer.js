const state = {
  activeTenant: "nike",
  customerToken: "",
  products: [],
  cart: [],
  search: "",
  storefrontSettings: null,
};

const $ = (id) => document.getElementById(id);

function ensureTenantDefaults(tenant) {
  return {
    tenant_name: tenant.charAt(0).toUpperCase() + tenant.slice(1),
    tenant_slug: tenant,
    customer_name: `${tenant} Buyer`,
    customer_email: `buyer@${tenant}.com`,
  };
}

function resolveTenantFromLocation() {
  const queryTenant = new URLSearchParams(window.location.search).get("tenant");
  if (queryTenant) return queryTenant;
  const host = window.location.hostname;
  if (!host || host === "localhost" || host === "127.0.0.1") return "nike";
  const parts = host.split(".");
  return parts.length > 2 ? parts[0] : "nike";
}

function baseUrls() {
  return {
    tenant: $("tenantApi").value.trim(),
    product: $("productApi").value.trim(),
    order: $("orderApi").value.trim(),
  };
}

function log(title, payload) {
  const stamp = new Date().toLocaleTimeString();
  const body = typeof payload === "string" ? payload : JSON.stringify(payload, null, 2);
  $("logOutput").textContent = `[${stamp}] ${title}\n${body}\n\n${$("logOutput").textContent}`;
}

function storageKey(kind) {
  return `customer:${state.activeTenant}:${kind}`;
}

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const text = await response.text();
  let data = text;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {}
  if (!response.ok) throw new Error(typeof data === "string" ? data : JSON.stringify(data));
  return data;
}

function authHeaders(token) {
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function formJson(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function currency(value) {
  const code = String(state.storefrontSettings?.currency || "INR").toUpperCase();
  const symbol = code === "INR" ? "Rs." : code === "USD" ? "$" : code === "EUR" ? "EUR" : code;
  return `${symbol} ${Number(value).toFixed(2)}`;
}

function escapeHtml(value) {
  return String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

function setToken(token) {
  state.customerToken = token;
  $("customerToken").value = token;
  localStorage.setItem(storageKey("customerToken"), token);
}

function updateHeader() {
  const defaults = ensureTenantDefaults(state.activeTenant);
  const settings = state.storefrontSettings || {};
  document.body.dataset.theme = state.activeTenant;
  document.documentElement.style.setProperty("--accent", settings.primary_color || "#111111");
  document.documentElement.style.setProperty("--accent-soft", settings.accent_color || "#eef2f7");
  $("shopTitle").textContent = `${settings.storefront_name || defaults.tenant_name} Store`;
  $("shopSubtitle").textContent = settings.hero_subtitle || "Customer storefront for this tenant.";
  $("tenantBadge").textContent = (settings.storefront_name || defaults.tenant_name).toUpperCase();
  $("customerStatus").textContent = state.customerToken ? `Logged in for ${defaults.tenant_slug}` : "Not logged in";
}

function renderMarketplace() {
  const term = state.search.trim().toLowerCase();
  const products = !term
    ? state.products
    : state.products.filter((product) => `${product.name} ${product.description || ""}`.toLowerCase().includes(term));

  const grid = $("productGrid");
  if (!products.length) {
    grid.innerHTML = '<div class="empty-card">No products for this tenant yet.</div>';
    return;
  }
  grid.innerHTML = products
    .map(
      (product) => `
        <article class="product-card">
          <h3>${escapeHtml(product.name)}</h3>
          <p class="muted">${escapeHtml(product.description || "No description yet.")}</p>
          <div class="product-meta"><span>${currency(product.price)}</span><span>${product.stock} in stock</span></div>
          <button type="button" class="add-cart-button" data-product-id="${product.id}" ${state.customerToken ? "" : "disabled"}>
            ${state.customerToken ? "Add to Cart" : "Login as Customer"}
          </button>
        </article>
      `
    )
    .join("");

  document.querySelectorAll(".add-cart-button").forEach((button) => {
    button.addEventListener("click", () => addToCartById(Number(button.dataset.productId)).catch((e) => log("Add failed", e.message)));
  });
}

function renderCart() {
  const cartItems = $("cartItems");
  if (!state.cart.length) {
    cartItems.innerHTML = '<div class="empty-card">Your cart is empty.</div>';
    return;
  }
  cartItems.innerHTML = state.cart
    .map(
      (item) => `
      <div class="cart-row">
        <div><strong>${escapeHtml(item.name || `Product #${item.product_id}`)}</strong><div class="muted">Quantity: ${item.quantity}</div></div>
        <div>
          <div>${item.price ? currency(item.price) : "Live price in service"}</div>
          <div class="table-actions">
            <button type="button" class="small-button secondary cart-inc" data-product-id="${item.product_id}" data-qty="${item.quantity}">+</button>
            <button type="button" class="small-button secondary cart-dec" data-product-id="${item.product_id}" data-qty="${item.quantity}">-</button>
            <button type="button" class="small-button cart-remove" data-product-id="${item.product_id}">Remove</button>
          </div>
        </div>
      </div>`
    )
    .join("");

  document.querySelectorAll(".cart-inc").forEach((button) => {
    button.addEventListener("click", () => {
      const productId = Number(button.dataset.productId);
      const qty = Number(button.dataset.qty || 1);
      updateCartQuantity(productId, qty + 1).catch((e) => log("Cart update failed", e.message));
    });
  });
  document.querySelectorAll(".cart-dec").forEach((button) => {
    button.addEventListener("click", () => {
      const productId = Number(button.dataset.productId);
      const qty = Number(button.dataset.qty || 1);
      updateCartQuantity(productId, Math.max(0, qty - 1)).catch((e) => log("Cart update failed", e.message));
    });
  });
  document.querySelectorAll(".cart-remove").forEach((button) => {
    button.addEventListener("click", () => {
      const productId = Number(button.dataset.productId);
      removeFromCart(productId).catch((e) => log("Cart remove failed", e.message));
    });
  });
}

function renderAll() {
  updateHeader();
  renderMarketplace();
  renderCart();
  $("checkoutBtn").disabled = !state.customerToken;
  $("loadCart").disabled = !state.customerToken;
}

function fillFormsForTenant() {
  const defaults = ensureTenantDefaults(state.activeTenant);
  const password = "Password123!";
  $("customerSignupForm").elements.tenant_slug.value = defaults.tenant_slug;
  $("customerSignupForm").elements.full_name.value = defaults.customer_name;
  $("customerSignupForm").elements.email.value = defaults.customer_email;
  $("customerSignupForm").elements.password.value = password;
  $("customerLoginForm").elements.tenant_slug.value = defaults.tenant_slug;
  $("customerLoginForm").elements.username.value = defaults.customer_email;
  $("customerLoginForm").elements.password.value = password;
}

async function loadStorefrontSettings() {
  const defaults = ensureTenantDefaults(state.activeTenant);
  state.storefrontSettings = { storefront_name: defaults.tenant_name, currency: "INR", primary_color: "#111111", accent_color: "#eef2f7" };
  try {
    const data = await request(`${baseUrls().tenant}/tenants/${state.activeTenant}/settings`);
    state.storefrontSettings = { ...state.storefrontSettings, ...(data.settings || {}) };
  } catch {}
  renderAll();
}

async function handleCustomerSignup(event) {
  event.preventDefault();
  const payload = formJson(event.currentTarget);
  const data = await request(`${baseUrls().tenant}/customers/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  log("Customer created", data);
}

async function loginCustomer(event) {
  event.preventDefault();
  const raw = formJson(event.currentTarget);
  let data;
  try {
    data = await request(`${baseUrls().tenant}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tenant_slug: raw.tenant_slug, username: raw.username, password: raw.password }),
    });
  } catch {
    data = await request(`${baseUrls().tenant}/auth/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(raw),
    });
  }
  setToken(data.access_token);
  log("Customer logged in", data);
  renderAll();
  await loadProducts();
  await loadCart();
}

async function loadProducts() {
  if (!state.customerToken) return;
  const data = await request(`${baseUrls().product}/products`, { headers: authHeaders(state.customerToken) });
  state.products = data.items || [];
  renderAll();
}

async function addToCartById(productId) {
  const data = await request(`${baseUrls().order}/cart/add`, {
    method: "POST",
    headers: { ...authHeaders(state.customerToken), "Content-Type": "application/json" },
    body: JSON.stringify({ product_id: productId, quantity: 1 }),
  });
  log("Cart updated", data);
  await loadCart();
}

async function loadCart() {
  if (!state.customerToken) return;
  const data = await request(`${baseUrls().order}/cart`, { headers: authHeaders(state.customerToken) });
  state.cart = data.items || [];
  renderCart();
}

async function updateCartQuantity(productId, quantity) {
  const data = await request(`${baseUrls().order}/cart/item/${productId}`, {
    method: "PATCH",
    headers: { ...authHeaders(state.customerToken), "Content-Type": "application/json" },
    body: JSON.stringify({ quantity }),
  });
  log("Cart quantity updated", data);
  await loadCart();
}

async function removeFromCart(productId) {
  const data = await request(`${baseUrls().order}/cart/remove/${productId}`, {
    method: "DELETE",
    headers: authHeaders(state.customerToken),
  });
  log("Cart item removed", data);
  await loadCart();
}

async function checkout() {
  const paymentMethod = ($("paymentMethod")?.value || "COD").toUpperCase();
  const data = await request(`${baseUrls().order}/orders/checkout`, {
    method: "POST",
    headers: { ...authHeaders(state.customerToken), "Content-Type": "application/json" },
    body: JSON.stringify({ payment_method: paymentMethod }),
  });
  $("orderOutput").textContent = JSON.stringify(data, null, 2);
  if (data.checkout_url) {
    window.location.href = data.checkout_url;
    return;
  }
  state.cart = [];
  renderAll();
  log("Checkout complete", data);
}

function clearSession() {
  localStorage.removeItem(storageKey("customerToken"));
  setToken("");
  state.cart = [];
  $("orderOutput").textContent = "Checkout response will appear here.";
  renderAll();
}

function bind() {
  document.querySelectorAll(".password-toggle").forEach((button) => {
    button.addEventListener("click", () => {
      const input = document.getElementById(button.dataset.target);
      const reveal = input.type === "password";
      input.type = reveal ? "text" : "password";
      button.textContent = reveal ? "Hide" : "Show";
    });
  });
  $("searchInput").addEventListener("input", (event) => {
    state.search = event.currentTarget.value;
    renderMarketplace();
  });
  $("customerSignupForm").addEventListener("submit", (e) => handleCustomerSignup(e).catch((err) => log("Signup failed", err.message)));
  $("customerLoginForm").addEventListener("submit", (e) => loginCustomer(e).catch((err) => log("Login failed", err.message)));
  $("marketRefresh").addEventListener("click", () => loadProducts().catch((err) => log("Refresh failed", err.message)));
  $("loadCart").addEventListener("click", () => loadCart().catch((err) => log("Cart load failed", err.message)));
  $("checkoutBtn").addEventListener("click", () => checkout().catch((err) => log("Checkout failed", err.message)));
  $("clearOutput").addEventListener("click", () => ($("logOutput").textContent = "Ready."));
  $("clearSession").addEventListener("click", clearSession);
  $("customerToken").addEventListener("change", (event) => setToken(event.currentTarget.value.trim()));
}

bind();
state.activeTenant = resolveTenantFromLocation();
fillFormsForTenant();
setToken(localStorage.getItem(storageKey("customerToken")) || "");
renderAll();
loadStorefrontSettings().catch(() => {});
if (state.customerToken) {
  loadProducts().catch(() => {});
  loadCart().catch(() => {});
}
