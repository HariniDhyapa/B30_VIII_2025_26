const state = {
  activeTenant: "nike",
  sellerToken: "",
  products: [],
  orders: [],
  storefrontSettings: null,
};

const $ = (id) => document.getElementById(id);

function ensureTenantDefaults(tenant) {
  return {
    tenant_name: tenant.charAt(0).toUpperCase() + tenant.slice(1),
    tenant_slug: tenant,
    seller_name: `${tenant} Owner`,
    seller_email: `seller@${tenant}.com`,
  };
}

function resolveTenantFromLocation() {
  const queryTenant = new URLSearchParams(window.location.search).get("tenant");
  return queryTenant || "nike";
}

function baseUrls() {
  return {
    tenant: $("tenantApi").value.trim(),
    product: $("productApi").value.trim(),
    order: $("orderApi").value.trim(),
  };
}

function log(title, payload) {
  const stamp = new Date().toLocaleTimeString();
  const body = typeof payload === "string" ? payload : JSON.stringify(payload, null, 2);
  $("logOutput").textContent = `[${stamp}] ${title}\n${body}\n\n${$("logOutput").textContent}`;
}

function storageKey(kind) {
  return `seller:${state.activeTenant}:${kind}`;
}

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const text = await response.text();
  let data = text;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {}
  if (!response.ok) throw new Error(typeof data === "string" ? data : JSON.stringify(data));
  return data;
}

function authHeaders(token) {
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function formJson(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function setToken(token) {
  state.sellerToken = token;
  $("sellerToken").value = token;
  localStorage.setItem(storageKey("sellerToken"), token);
}

function updateHeader() {
  const defaults = ensureTenantDefaults(state.activeTenant);
  const settings = state.storefrontSettings || {};
  document.body.dataset.theme = state.activeTenant;
  document.documentElement.style.setProperty("--accent", settings.primary_color || "#111111");
  document.documentElement.style.setProperty("--accent-soft", settings.accent_color || "#eef2f7");
  $("shopTitle").textContent = `${settings.storefront_name || defaults.tenant_name} Store Admin`;
  $("tenantBadge").textContent = (settings.storefront_name || defaults.tenant_name).toUpperCase();
  $("sellerStatus").textContent = state.sellerToken ? `Logged in for ${defaults.tenant_slug}` : "Not logged in";
}

function renderInventory() {
  const body = $("inventoryBody");
  if (!state.products.length) {
    body.innerHTML = '<tr><td colspan="4" class="empty-cell">No products yet.</td></tr>';
    return;
  }
  body.innerHTML = state.products
    .map(
      (product) => `
      <tr>
        <td><strong>${product.name}</strong><br /><span class="muted">${product.description || ""}</span></td>
        <td>${Number(product.price).toFixed(2)}</td>
        <td>${product.stock}</td>
        <td>
          <div class="table-actions">
            <button type="button" class="small-button secondary edit-product" data-product-id="${product.id}">Edit</button>
            <button type="button" class="small-button delete-product" data-product-id="${product.id}">Delete</button>
          </div>
        </td>
      </tr>`
    )
    .join("");

  document.querySelectorAll(".edit-product").forEach((button) => {
    button.addEventListener("click", () => editProduct(Number(button.dataset.productId)).catch((e) => log("Edit failed", e.message)));
  });
  document.querySelectorAll(".delete-product").forEach((button) => {
    button.addEventListener("click", () => deleteProduct(Number(button.dataset.productId)).catch((e) => log("Delete failed", e.message)));
  });
}

function renderAll() {
  updateHeader();
  renderInventory();
  renderOrders();
}

function renderOrders() {
  const body = $("ordersBody");
  if (!state.orders.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty-cell">No orders yet for this tenant.</td></tr>';
    return;
  }
  body.innerHTML = state.orders
    .map(
      (order) => `
      <tr>
        <td>#${order.id}</td>
        <td>${order.user_id}</td>
        <td>${order.status}</td>
        <td>${Number(order.total_amount).toFixed(2)}</td>
        <td>${new Date(order.created_at).toLocaleString()}</td>
      </tr>`
    )
    .join("");
}

function fillFormsForTenant() {
  const defaults = ensureTenantDefaults(state.activeTenant);
  const password = "Password123!";
  $("tenantSignupForm").elements.tenant_name.value = defaults.tenant_name;
  $("tenantSignupForm").elements.tenant_slug.value = defaults.tenant_slug;
  $("tenantSignupForm").elements.seller_name.value = defaults.seller_name;
  $("tenantSignupForm").elements.seller_email.value = defaults.seller_email;
  $("tenantSignupForm").elements.password.value = password;
  $("sellerLoginForm").elements.tenant_slug.value = defaults.tenant_slug;
  $("sellerLoginForm").elements.username.value = defaults.seller_email;
  $("sellerLoginForm").elements.password.value = password;
}

async function loadStorefrontSettings() {
  const defaults = ensureTenantDefaults(state.activeTenant);
  state.storefrontSettings = { storefront_name: defaults.tenant_name, primary_color: "#111111", accent_color: "#eef2f7" };
  try {
    const data = await request(`${baseUrls().tenant}/tenants/${state.activeTenant}/settings`);
    state.storefrontSettings = { ...state.storefrontSettings, ...(data.settings || {}) };
  } catch {}
  renderAll();
}

async function handleTenantSignup(event) {
  event.preventDefault();
  const payload = formJson(event.currentTarget);
  const data = await request(`${baseUrls().tenant}/tenants/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  log("Tenant created", data);
  await loadStorefrontSettings();
}

async function loginSeller(event) {
  event.preventDefault();
  const raw = formJson(event.currentTarget);
  let data;
  try {
    data = await request(`${baseUrls().tenant}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tenant_slug: raw.tenant_slug, username: raw.username, password: raw.password }),
    });
  } catch {
    data = await request(`${baseUrls().tenant}/auth/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(raw),
    });
  }
  setToken(data.access_token);
  log("Seller logged in", data);
  renderAll();
  await loadProducts();
  await loadOrders();
}

async function loadProducts() {
  if (!state.sellerToken) return;
  const data = await request(`${baseUrls().product}/products`, { headers: authHeaders(state.sellerToken) });
  state.products = data.items || [];
  renderAll();
}

async function loadOrders() {
  if (!state.sellerToken) return;
  const data = await request(`${baseUrls().order}/seller/orders`, { headers: authHeaders(state.sellerToken) });
  state.orders = data.items || [];
  renderAll();
}

async function createProduct(event) {
  event.preventDefault();
  const payload = formJson(event.currentTarget);
  payload.price = Number(payload.price);
  payload.stock = Number(payload.stock);
  const data = await request(`${baseUrls().product}/products`, {
    method: "POST",
    headers: { ...authHeaders(state.sellerToken), "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  log("Product created", data);
  await loadProducts();
  await loadOrders();
}

async function editProduct(productId) {
  const product = state.products.find((item) => Number(item.id) === productId);
  if (!product) return;
  const name = window.prompt("Product name", product.name);
  if (name === null) return;
  const price = window.prompt("Price", product.price);
  if (price === null) return;
  const stock = window.prompt("Stock", product.stock);
  if (stock === null) return;
  const data = await request(`${baseUrls().product}/products/${productId}`, {
    method: "PATCH",
    headers: { ...authHeaders(state.sellerToken), "Content-Type": "application/json" },
    body: JSON.stringify({ name, price: Number(price), stock: Number(stock) }),
  });
  log("Product updated", data);
  await loadProducts();
  await loadOrders();
}

async function deleteProduct(productId) {
  if (!window.confirm("Delete this product?")) return;
  const data = await request(`${baseUrls().product}/products/${productId}`, {
    method: "DELETE",
    headers: authHeaders(state.sellerToken),
  });
  log("Product deleted", data);
  await loadProducts();
  await loadOrders();
}

function clearSession() {
  localStorage.removeItem(storageKey("sellerToken"));
  setToken("");
  state.orders = [];
  renderAll();
}

function openStorefront() {
  const base = $("storefrontUrl").value.trim().replace(/\/$/, "");
  window.open(`${base}/?tenant=${state.activeTenant}`, "_blank", "noopener,noreferrer");
}

function bind() {
  document.querySelectorAll(".password-toggle").forEach((button) => {
    button.addEventListener("click", () => {
      const input = document.getElementById(button.dataset.target);
      const reveal = input.type === "password";
      input.type = reveal ? "text" : "password";
      button.textContent = reveal ? "Hide" : "Show";
    });
  });
  $("tenantSignupForm").addEventListener("submit", (e) => handleTenantSignup(e).catch((err) => log("Tenant create failed", err.message)));
  $("sellerLoginForm").addEventListener("submit", (e) => loginSeller(e).catch((err) => log("Seller login failed", err.message)));
  $("productForm").addEventListener("submit", (e) => createProduct(e).catch((err) => log("Product create failed", err.message)));
  $("sellerRefresh").addEventListener("click", () => loadProducts().catch((err) => log("Refresh failed", err.message)));
  $("ordersRefresh").addEventListener("click", () => loadOrders().catch((err) => log("Orders refresh failed", err.message)));
  $("openStorefront").addEventListener("click", openStorefront);
  $("clearSession").addEventListener("click", clearSession);
  $("clearOutput").addEventListener("click", () => ($("logOutput").textContent = "Ready."));
  $("sellerToken").addEventListener("change", (event) => setToken(event.currentTarget.value.trim()));
}

bind();
state.activeTenant = resolveTenantFromLocation();
fillFormsForTenant();
setToken(localStorage.getItem(storageKey("sellerToken")) || "");
renderAll();
loadStorefrontSettings().catch(() => {});
if (state.sellerToken) {
  loadProducts().catch(() => {});
  loadOrders().catch(() => {});
}
