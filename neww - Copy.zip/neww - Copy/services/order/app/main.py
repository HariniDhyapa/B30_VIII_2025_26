import json
import threading
import time
from datetime import datetime
from decimal import Decimal
from typing import Generator

import httpx
import pika
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from common.auth import decode_access_token, validate_schema_name
from common.config import settings
from common.cors import apply_cors
from common.db import SessionLocal, reset_schema, set_tenant_schema
from common.rabbitmq import publish_event
from common.redis_client import get_redis_client

app = FastAPI(title="Order Service", version="1.0.0")
apply_cors(app)
redis_client = get_redis_client()
bearer_scheme = HTTPBearer()


class CartItemIn(BaseModel):
    product_id: int
    quantity: int = Field(ge=1)


class CartQuantityUpdateIn(BaseModel):
    quantity: int = Field(ge=0)


class CheckoutIn(BaseModel):
    payment_method: str = "COD"


def db_session() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def tenant_context(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)) -> dict:
    try:
        payload = decode_access_token(credentials.credentials)
        payload["schema"] = validate_schema_name(payload["schema"])
        return payload
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token") from exc


def require_roles(ctx: dict, allowed_roles: set[str]) -> None:
    if ctx.get("role") not in allowed_roles:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient role")


def customer_context(ctx: dict = Depends(tenant_context)) -> dict:
    require_roles(ctx, {"customer"})
    return ctx


def seller_context(ctx: dict = Depends(tenant_context)) -> dict:
    require_roles(ctx, {"seller", "admin"})
    return ctx


def cart_key(schema: str, user_id: str) -> str:
    return f"{schema}:cart:{user_id}"


def product_cache_keys(schema: str, product_id: int | None = None) -> list[str]:
    keys = [f"{schema}:products:all"]
    if product_id is not None:
        keys.append(f"{schema}:products:{product_id}")
    return keys


def clear_product_cache(schema: str, product_id: int | None = None) -> None:
    redis_client.delete(*product_cache_keys(schema, product_id))


def payment_urls(order_id: int, tenant_slug: str) -> dict:
    frontend_base = settings.frontend_base_url.rstrip("/")
    return {
        "success_url": f"{frontend_base}/?tenant={tenant_slug}&payment=success&order_id={order_id}&session_id={{CHECKOUT_SESSION_ID}}",
        "cancel_url": f"{frontend_base}/?tenant={tenant_slug}&payment=cancelled&order_id={order_id}",
    }


def load_product_snapshot(db: Session, schema: str, product_id: int, *, for_update: bool = False) -> dict | None:
    set_tenant_schema(db, schema)
    lock_clause = " FOR UPDATE" if for_update else ""
    product = db.execute(
        text(
            f"""
            SELECT id, name, description, price::text, stock
            FROM products
            WHERE id=:id{lock_clause}
            """
        ),
        {"id": product_id},
    ).mappings().first()
    reset_schema(db)
    return dict(product) if product else None


def consume_payment_events() -> None:
    while True:
        try:
            connection = pika.BlockingConnection(pika.URLParameters(settings.rabbitmq_url))
            channel = connection.channel()
            channel.exchange_declare(exchange="commerce", exchange_type="topic", durable=True)
            channel.queue_declare(queue="order.payment.succeeded", durable=True)
            channel.queue_bind(exchange="commerce", queue="order.payment.succeeded", routing_key="payment.succeeded")

            def callback(ch, method, properties, body):
                payload = json.loads(body.decode("utf-8"))
                schema = validate_schema_name(payload["schema"])
                order_id = int(payload["order_id"])

                db = SessionLocal()
                try:
                    set_tenant_schema(db, schema)
                    db.execute(
                        text("UPDATE orders SET status='PAID', updated_at=NOW() WHERE id=:order_id"),
                        {"order_id": order_id},
                    )
                    db.commit()
                    reset_schema(db)
                    ch.basic_ack(delivery_tag=method.delivery_tag)
                except Exception:
                    db.rollback()
                    ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
                finally:
                    db.close()

            channel.basic_qos(prefetch_count=5)
            channel.basic_consume(queue="order.payment.succeeded", on_message_callback=callback)
            channel.start_consuming()
        except Exception:
            time.sleep(3)


@app.on_event("startup")
def startup() -> None:
    t = threading.Thread(target=consume_payment_events, daemon=True)
    t.start()


@app.get("/health")
def health() -> dict:
    return {"service": settings.service_name, "status": "ok", "ts": datetime.utcnow().isoformat()}


@app.post("/cart/add")
def add_to_cart(item: CartItemIn, ctx: dict = Depends(customer_context), db: Session = Depends(db_session)) -> dict:
    product = load_product_snapshot(db, ctx["schema"], item.product_id)
    if not product:
        raise HTTPException(status_code=400, detail="Invalid product")
    key = cart_key(ctx["schema"], ctx["sub"])
    existing_quantity = int(redis_client.hget(key, str(item.product_id)) or 0)
    requested_total = existing_quantity + item.quantity
    if int(product["stock"]) < requested_total:
        raise HTTPException(status_code=400, detail="Requested quantity exceeds available stock")

    redis_client.hincrby(key, str(item.product_id), item.quantity)
    redis_client.expire(key, 86400)
    quantity = int(redis_client.hget(key, str(item.product_id)) or 0)
    return {
        "message": "added",
        "cart_key": key,
        "item": {
            "product_id": item.product_id,
            "name": product["name"],
            "price": product["price"],
            "quantity": quantity,
        },
    }


@app.delete("/cart/remove/{product_id}")
def remove_from_cart(product_id: int, ctx: dict = Depends(customer_context)) -> dict:
    key = cart_key(ctx["schema"], ctx["sub"])
    redis_client.hdel(key, str(product_id))
    return {"message": "removed", "product_id": product_id}


@app.patch("/cart/item/{product_id}")
def update_cart_item_quantity(
    product_id: int,
    payload: CartQuantityUpdateIn,
    ctx: dict = Depends(customer_context),
    db: Session = Depends(db_session),
) -> dict:
    key = cart_key(ctx["schema"], ctx["sub"])
    if payload.quantity == 0:
        redis_client.hdel(key, str(product_id))
        return {"message": "removed", "product_id": product_id, "quantity": 0}

    product = load_product_snapshot(db, ctx["schema"], product_id)
    if not product:
        raise HTTPException(status_code=400, detail="Invalid product")
    if int(product["stock"]) < payload.quantity:
        raise HTTPException(status_code=400, detail="Requested quantity exceeds available stock")

    redis_client.hset(key, str(product_id), payload.quantity)
    redis_client.expire(key, 86400)
    return {"message": "updated", "product_id": product_id, "quantity": payload.quantity}


@app.get("/cart")
def view_cart(ctx: dict = Depends(customer_context), db: Session = Depends(db_session)) -> dict:
    key = cart_key(ctx["schema"], ctx["sub"])
    cart = redis_client.hgetall(key)
    items = []
    for product_id, quantity in cart.items():
        product = load_product_snapshot(db, ctx["schema"], int(product_id))
        items.append(
            {
                "product_id": int(product_id),
                "quantity": int(quantity),
                "name": product["name"] if product else "Unavailable product",
                "price": product["price"] if product else None,
            }
        )
    return {"items": items}


@app.post("/orders/checkout")
def checkout(payload: CheckoutIn, ctx: dict = Depends(customer_context), db: Session = Depends(db_session)) -> dict:
    payment_method = (payload.payment_method or "COD").upper()
    if payment_method not in {"COD", "ONLINE_MOCK"}:
        raise HTTPException(status_code=400, detail="Unsupported payment_method. Use COD or ONLINE_MOCK.")

    key = cart_key(ctx["schema"], ctx["sub"])
    cart = redis_client.hgetall(key)
    if not cart:
        raise HTTPException(status_code=400, detail="Cart is empty")

    items = []
    total = Decimal("0")
    touched_product_ids: list[int] = []
    try:
        for product_id, qty in cart.items():
            quantity = int(qty)
            if quantity < 1:
                raise HTTPException(status_code=400, detail=f"Invalid quantity in cart for product {product_id}")
            product = load_product_snapshot(db, ctx["schema"], int(product_id), for_update=True)
            if not product:
                raise HTTPException(status_code=400, detail=f"Product {product_id} unavailable")
            if int(product["stock"]) < quantity:
                raise HTTPException(status_code=400, detail=f"Insufficient stock for product {product['name']}")

            line_total = Decimal(product["price"]) * quantity
            total += line_total
            items.append(
                {
                    "product_id": int(product_id),
                    "name": product["name"],
                    "price": product["price"],
                    "quantity": quantity,
                    "line_total": str(line_total),
                }
            )

            set_tenant_schema(db, ctx["schema"])
            updated = db.execute(
                text(
                    """
                    UPDATE products
                    SET stock = stock - :quantity, updated_at=NOW()
                    WHERE id=:id AND stock >= :quantity
                    """
                ),
                {"id": int(product_id), "quantity": quantity},
            )
            if updated.rowcount != 1:
                raise HTTPException(status_code=400, detail=f"Unable to reserve stock for product {product['name']}")
            reset_schema(db)
            touched_product_ids.append(int(product_id))

        set_tenant_schema(db, ctx["schema"])
        order_status = "PENDING_COD" if payment_method == "COD" else "PENDING"
        order = db.execute(
            text(
                """
                INSERT INTO orders(user_id, status, total_amount, items)
                VALUES (:user_id, :status, :total_amount, CAST(:items AS JSONB))
                RETURNING id, user_id, status, total_amount::text, items, created_at
                """
            ),
            {"user_id": int(ctx["sub"]), "status": order_status, "total_amount": total, "items": json.dumps(items)},
        ).mappings().first()
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail="Checkout failed") from exc
    finally:
        reset_schema(db)

    redis_client.delete(key)
    for product_id in touched_product_ids:
        clear_product_cache(ctx["schema"], product_id)

    provider = settings.payment_provider.lower()
    if provider == "stripe":
        urls = payment_urls(order["id"], ctx["tenant_slug"])
        payload = {
            "order_id": order["id"],
            "tenant_id": ctx["tenant_id"],
            "tenant_slug": ctx["tenant_slug"],
            "schema": ctx["schema"],
            "user_id": int(ctx["sub"]),
            "amount": order["total_amount"],
            "items": [
                {"name": row["name"], "quantity": row["quantity"], "price": row["price"]}
                for row in items
            ],
            "success_url": urls["success_url"],
            "cancel_url": urls["cancel_url"],
        }
        try:
            with httpx.Client(timeout=20) as client:
                resp = client.post(
                    f"{settings.payment_service_url.rstrip('/')}/checkout-session",
                    json=payload,
                    headers={"x-internal-key": settings.payment_internal_api_key},
                )
            if resp.status_code >= 400:
                raise HTTPException(status_code=502, detail=f"Payment session failed: {resp.text}")
            session_data = resp.json()
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Payment service unreachable: {exc}") from exc

        return {
            "message": "order placed, payment pending",
            "payment_provider": "stripe",
            "payment_method": payment_method,
            "checkout_url": session_data.get("checkout_url"),
            "order": dict(order),
        }

    if payment_method == "ONLINE_MOCK":
        publish_event(
            "order.created",
            {
                "order_id": order["id"],
                "tenant_id": ctx["tenant_id"],
                "tenant_slug": ctx["tenant_slug"],
                "schema": ctx["schema"],
                "user_id": int(ctx["sub"]),
                "amount": order["total_amount"],
            },
        )
        return {
            "message": "order placed, online payment pending",
            "payment_provider": "mock",
            "payment_method": payment_method,
            "order": dict(order),
        }

    return {
        "message": "order placed with cash on delivery",
        "payment_provider": "mock",
        "payment_method": payment_method,
        "order": dict(order),
    }


@app.get("/orders")
def order_history(ctx: dict = Depends(customer_context), db: Session = Depends(db_session)) -> dict:
    set_tenant_schema(db, ctx["schema"])
    rows = db.execute(
        text(
            "SELECT id, user_id, status, total_amount::text, items, created_at, updated_at FROM orders WHERE user_id=:uid ORDER BY id DESC"
        ),
        {"uid": int(ctx["sub"])}
    ).mappings().all()
    reset_schema(db)
    return {"items": [dict(r) for r in rows]}


@app.get("/seller/orders")
def seller_order_history(ctx: dict = Depends(seller_context), db: Session = Depends(db_session)) -> dict:
    set_tenant_schema(db, ctx["schema"])
    rows = db.execute(
        text(
            """
            SELECT id, user_id, status, total_amount::text, items, created_at, updated_at
            FROM orders
            ORDER BY id DESC
            """
        )
    ).mappings().all()
    reset_schema(db)
    return {"items": [dict(r) for r in rows]}
