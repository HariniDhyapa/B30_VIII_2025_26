import json
import random
import threading
import time
from datetime import datetime
from decimal import Decimal

import pika
import stripe
from fastapi import FastAPI, Header, HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy import text

from common.auth import validate_schema_name
from common.config import settings
from common.cors import apply_cors
from common.db import SessionLocal, reset_schema, set_tenant_schema
from common.rabbitmq import publish_event

app = FastAPI(title="Payment Service", version="1.0.0")
apply_cors(app)
stripe.api_key = settings.stripe_secret_key or None


class CheckoutItem(BaseModel):
    name: str
    quantity: int
    price: str


class CheckoutSessionIn(BaseModel):
    order_id: int
    tenant_id: int
    tenant_slug: str
    schema: str
    user_id: int
    amount: str
    items: list[CheckoutItem]
    success_url: str
    cancel_url: str


def require_internal_key(x_internal_key: str | None) -> None:
    if x_internal_key != settings.payment_internal_api_key:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid internal key")


def insert_payment(schema: str, order_id: int, status_value: str, amount: str) -> None:
    db = SessionLocal()
    try:
        set_tenant_schema(db, schema)
        db.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS payments (
                  id BIGSERIAL PRIMARY KEY,
                  order_id BIGINT NOT NULL,
                  status VARCHAR(32) NOT NULL,
                  amount NUMERIC(10,2) NOT NULL,
                  created_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
                """
            )
        )
        db.execute(
            text("INSERT INTO payments(order_id, status, amount) VALUES (:order_id, :status, :amount)"),
            {"order_id": order_id, "status": status_value, "amount": amount},
        )
        db.commit()
        reset_schema(db)
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def consume_orders() -> None:
    while True:
        try:
            connection = pika.BlockingConnection(pika.URLParameters(settings.rabbitmq_url))
            channel = connection.channel()
            channel.exchange_declare(exchange="commerce", exchange_type="topic", durable=True)
            channel.queue_declare(queue="payment.order.created", durable=True)
            channel.queue_bind(exchange="commerce", queue="payment.order.created", routing_key="order.created")

            def callback(ch, method, properties, body):
                payload = json.loads(body.decode("utf-8"))
                schema = validate_schema_name(payload["schema"])
                order_id = int(payload["order_id"])
                amount = payload["amount"]

                # Mock payment processing latency.
                time.sleep(1)
                success = random.random() <= settings.payment_success_rate

                db = SessionLocal()
                try:
                    set_tenant_schema(db, schema)
                    db.execute(
                        text(
                            """
                            CREATE TABLE IF NOT EXISTS payments (
                              id BIGSERIAL PRIMARY KEY,
                              order_id BIGINT NOT NULL,
                              status VARCHAR(32) NOT NULL,
                              amount NUMERIC(10,2) NOT NULL,
                              created_at TIMESTAMP NOT NULL DEFAULT NOW()
                            )
                            """
                        )
                    )
                    db.execute(
                        text("INSERT INTO payments(order_id, status, amount) VALUES (:order_id, :status, :amount)"),
                        {"order_id": order_id, "status": "SUCCEEDED" if success else "FAILED", "amount": amount},
                    )
                    db.commit()
                    reset_schema(db)

                    if success:
                        publish_event(
                            "payment.succeeded",
                            {
                                "order_id": order_id,
                                "schema": schema,
                                "tenant_id": payload["tenant_id"],
                                "tenant_slug": payload["tenant_slug"],
                            },
                        )

                    ch.basic_ack(delivery_tag=method.delivery_tag)
                except Exception:
                    db.rollback()
                    ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
                finally:
                    db.close()

            channel.basic_qos(prefetch_count=10)
            channel.basic_consume(queue="payment.order.created", on_message_callback=callback)
            channel.start_consuming()
        except Exception:
            time.sleep(3)


@app.on_event("startup")
def startup() -> None:
    if settings.payment_provider.lower() == "mock":
        t = threading.Thread(target=consume_orders, daemon=True)
        t.start()


@app.get("/health")
def health() -> dict:
    return {"service": settings.service_name, "status": "ok", "ts": datetime.utcnow().isoformat()}


@app.post("/checkout-session")
def create_checkout_session(payload: CheckoutSessionIn, x_internal_key: str | None = Header(default=None)) -> dict:
    require_internal_key(x_internal_key)
    if settings.payment_provider.lower() != "stripe":
        raise HTTPException(status_code=400, detail="Stripe provider is not enabled")
    if not settings.stripe_secret_key:
        raise HTTPException(status_code=500, detail="Stripe secret key is not configured")

    schema = validate_schema_name(payload.schema)
    line_items = []
    for item in payload.items:
        unit_amount = int((Decimal(item.price) * 100).quantize(Decimal("1")))
        line_items.append(
            {
                "price_data": {
                    "currency": "inr",
                    "product_data": {"name": item.name},
                    "unit_amount": unit_amount,
                },
                "quantity": item.quantity,
            }
        )

    try:
        session = stripe.checkout.Session.create(
            mode="payment",
            line_items=line_items,
            success_url=payload.success_url,
            cancel_url=payload.cancel_url,
            metadata={
                "order_id": str(payload.order_id),
                "schema": schema,
                "tenant_id": str(payload.tenant_id),
                "tenant_slug": payload.tenant_slug,
                "user_id": str(payload.user_id),
            },
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Stripe checkout session creation failed: {exc}") from exc

    return {"checkout_url": session.url, "session_id": session.id}


@app.post("/webhooks/stripe")
async def stripe_webhook(request: Request) -> dict:
    if settings.payment_provider.lower() != "stripe":
        return {"status": "ignored", "reason": "provider_not_stripe"}

    payload = await request.body()
    signature = request.headers.get("stripe-signature")
    event = None
    try:
        if settings.stripe_webhook_secret:
            event = stripe.Webhook.construct_event(payload=payload, sig_header=signature, secret=settings.stripe_webhook_secret)
        else:
            event = json.loads(payload.decode("utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid Stripe webhook payload: {exc}") from exc

    event_type = event.get("type")
    data_object = (event.get("data") or {}).get("object", {})
    metadata = data_object.get("metadata") or {}
    order_id = metadata.get("order_id")
    schema = metadata.get("schema")
    tenant_id = metadata.get("tenant_id")
    tenant_slug = metadata.get("tenant_slug")
    amount_total = data_object.get("amount_total")

    if not order_id or not schema:
        return {"status": "ignored", "reason": "missing_order_metadata"}

    schema = validate_schema_name(schema)
    amount_value = str((Decimal(amount_total or 0) / 100).quantize(Decimal("0.01")))

    if event_type == "checkout.session.completed":
        insert_payment(schema, int(order_id), "SUCCEEDED", amount_value)
        publish_event(
            "payment.succeeded",
            {
                "order_id": int(order_id),
                "schema": schema,
                "tenant_id": int(tenant_id) if tenant_id else 0,
                "tenant_slug": tenant_slug or "",
            },
        )
    elif event_type in {"checkout.session.expired", "payment_intent.payment_failed"}:
        insert_payment(schema, int(order_id), "FAILED", amount_value)

    return {"status": "ok"}
