import json
from datetime import datetime
from decimal import Decimal
from typing import Generator

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from common.auth import decode_access_token, validate_schema_name
from common.config import settings
from common.cors import apply_cors
from common.db import SessionLocal, reset_schema, set_tenant_schema
from common.redis_client import get_redis_client

app = FastAPI(title="Product Service", version="1.0.0")
apply_cors(app)
redis_client = get_redis_client()
bearer_scheme = HTTPBearer()


class ProductIn(BaseModel):
    name: str = Field(min_length=2)
    description: str = ""
    price: Decimal = Field(gt=0)
    stock: int = Field(ge=0)


class ProductUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    price: Decimal | None = Field(default=None, gt=0)
    stock: int | None = Field(default=None, ge=0)


def db_session() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def tenant_context(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)) -> dict:
    try:
        payload = decode_access_token(credentials.credentials)
        payload["schema"] = validate_schema_name(payload["schema"])
        return payload
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token") from exc


def require_roles(ctx: dict, allowed_roles: set[str]) -> None:
    if ctx.get("role") not in allowed_roles:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient role")


def clear_product_cache(schema: str, product_id: int | None = None) -> None:
    redis_client.delete(f"{schema}:products:all")
    if product_id is not None:
        redis_client.delete(f"{schema}:products:{product_id}")


@app.get("/health")
def health() -> dict:
    return {"service": settings.service_name, "status": "ok", "ts": datetime.utcnow().isoformat()}


@app.post("/products")
def create_product(payload: ProductIn, ctx: dict = Depends(tenant_context), db: Session = Depends(db_session)) -> dict:
    require_roles(ctx, {"seller"})
    set_tenant_schema(db, ctx["schema"])
    product = db.execute(
        text(
            """
            INSERT INTO products(name, description, price, stock)
            VALUES (:name, :description, :price, :stock)
            RETURNING id, name, description, price::text, stock
            """
        ),
        payload.model_dump(),
    ).mappings().first()
    db.commit()
    reset_schema(db)

    clear_product_cache(ctx["schema"])
    return dict(product)


@app.get("/products")
def list_products(ctx: dict = Depends(tenant_context), db: Session = Depends(db_session)) -> dict:
    cache_key = f"{ctx['schema']}:products:all"
    cached = redis_client.get(cache_key)
    if cached:
        return {"items": json.loads(cached), "source": "cache"}

    set_tenant_schema(db, ctx["schema"])
    products = db.execute(
        text("SELECT id, name, description, price::text, stock FROM products ORDER BY id DESC")
    ).mappings().all()
    reset_schema(db)

    items = [dict(x) for x in products]
    redis_client.setex(cache_key, 60, json.dumps(items))
    return {"items": items, "source": "db"}


@app.get("/products/{product_id}")
def get_product(product_id: int, ctx: dict = Depends(tenant_context), db: Session = Depends(db_session)) -> dict:
    cache_key = f"{ctx['schema']}:products:{product_id}"
    cached = redis_client.get(cache_key)
    if cached:
        return {"item": json.loads(cached), "source": "cache"}

    set_tenant_schema(db, ctx["schema"])
    product = db.execute(
        text("SELECT id, name, description, price::text, stock FROM products WHERE id=:id"), {"id": product_id}
    ).mappings().first()
    reset_schema(db)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    item = dict(product)
    redis_client.setex(cache_key, 60, json.dumps(item))
    return {"item": item, "source": "db"}


@app.patch("/products/{product_id}")
def update_product(product_id: int, payload: ProductUpdate, ctx: dict = Depends(tenant_context), db: Session = Depends(db_session)) -> dict:
    require_roles(ctx, {"seller"})
    data = {k: v for k, v in payload.model_dump().items() if v is not None}
    if not data:
        raise HTTPException(status_code=400, detail="No fields provided")

    fields = ", ".join([f"{k}=:{k}" for k in data.keys()])
    data["id"] = product_id

    set_tenant_schema(db, ctx["schema"])
    product = db.execute(
        text(f"UPDATE products SET {fields}, updated_at=NOW() WHERE id=:id RETURNING id, name, description, price::text, stock")
        , data
    ).mappings().first()
    db.commit()
    reset_schema(db)

    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    clear_product_cache(ctx["schema"], product_id)
    return dict(product)


@app.delete("/products/{product_id}")
def delete_product(product_id: int, ctx: dict = Depends(tenant_context), db: Session = Depends(db_session)) -> dict:
    require_roles(ctx, {"seller"})
    set_tenant_schema(db, ctx["schema"])
    result = db.execute(text("DELETE FROM products WHERE id=:id"), {"id": product_id})
    db.commit()
    reset_schema(db)

    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="Product not found")

    clear_product_cache(ctx["schema"], product_id)
    return {"message": "deleted", "product_id": product_id}
