from datetime import datetime
from typing import Any, Generator

from fastapi import Depends, FastAPI, Form, Header, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from common.auth import create_access_token, decode_access_token, validate_schema_name
from common.config import settings
from common.cors import apply_cors
from common.db import SessionLocal, engine, reset_schema, set_tenant_schema

app = FastAPI(title="Tenant-User Service", version="1.0.0")
apply_cors(app)
pwd_ctx = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")
bearer_scheme = HTTPBearer()


class TenantSignupIn(BaseModel):
    tenant_name: str = Field(min_length=2)
    tenant_slug: str = Field(pattern=r"^[a-z0-9-]{2,40}$")
    seller_name: str = Field(min_length=2, max_length=120)
    seller_email: EmailStr | None = None
    admin_email: EmailStr | None = None
    password: str = Field(min_length=8)


class CustomerSignupIn(BaseModel):
    tenant_slug: str
    email: EmailStr
    password: str = Field(min_length=8)
    full_name: str = Field(min_length=2, max_length=120)


class LoginIn(BaseModel):
    tenant_slug: str
    username: EmailStr
    password: str = Field(min_length=8)


class TenantSettingsIn(BaseModel):
    storefront_name: str | None = Field(default=None, min_length=2, max_length=120)
    logo_url: str | None = None
    primary_color: str = Field(default="#111111", pattern=r"^#[0-9A-Fa-f]{6}$")
    accent_color: str = Field(default="#eef2f7", pattern=r"^#[0-9A-Fa-f]{6}$")
    support_email: EmailStr | None = None
    support_phone: str | None = Field(default=None, max_length=40)
    currency: str = Field(default="INR", min_length=3, max_length=10)
    storefront_domain: str | None = Field(default=None, max_length=255)
    hero_title: str | None = Field(default=None, max_length=255)
    hero_subtitle: str | None = None


class ProductSeedIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    description: str | None = None
    price: float = Field(gt=0)
    stock: int = Field(ge=0)


class TenantProvisionIn(BaseModel):
    tenant_name: str = Field(min_length=2)
    tenant_slug: str = Field(pattern=r"^[a-z0-9-]{2,40}$")
    seller_name: str = Field(min_length=2, max_length=120)
    seller_email: EmailStr | None = None
    admin_email: EmailStr | None = None
    password: str = Field(min_length=8)
    settings: TenantSettingsIn = Field(default_factory=TenantSettingsIn)
    sample_products: list[ProductSeedIn] = Field(default_factory=list, max_length=20)


class SellerPasswordResetIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)


class PlatformLoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)


def db_session() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_token_payload(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)) -> dict:
    try:
        return decode_access_token(credentials.credentials)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc


def get_platform_admin_payload(token_data: dict = Depends(get_token_payload)) -> dict:
    if token_data.get("role") != "platform_admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Platform admin access required")
    return token_data


def resolve_seller_email(payload: TenantSignupIn) -> str:
    seller_email = payload.seller_email or payload.admin_email
    if not seller_email:
        raise HTTPException(status_code=422, detail="seller_email is required")
    return str(seller_email)


def resolve_seller_email_for_provision(payload: TenantProvisionIn) -> str:
    seller_email = payload.seller_email or payload.admin_email
    if not seller_email:
        raise HTTPException(status_code=422, detail="seller_email is required")
    return str(seller_email)


def require_provisioning_key(x_provision_key: str | None = Header(default=None)) -> None:
    if settings.provisioning_api_key and x_provision_key != settings.provisioning_api_key:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid provisioning key")


def get_tenant_by_slug(db: Session, tenant_slug: str) -> dict:
    tenant = db.execute(
        text("SELECT id, name, slug, schema_name FROM public.tenants WHERE slug=:slug"),
        {"slug": tenant_slug},
    ).mappings().first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return dict(tenant)


def issue_access_token(db: Session, tenant_slug: str, username: str, password: str) -> dict:
    tenant = get_tenant_by_slug(db, tenant_slug)
    ensure_tenant_schema_objects(db, tenant["schema_name"])

    set_tenant_schema(db, tenant["schema_name"])
    user = db.execute(
        text("SELECT id, email, full_name, password_hash, role FROM users WHERE email=:email"),
        {"email": username},
    ).mappings().first()
    reset_schema(db)

    if not user or not pwd_ctx.verify(password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token(
        {
            "sub": str(user["id"]),
            "email": user["email"],
            "full_name": user["full_name"],
            "role": user["role"],
            "tenant_id": tenant["id"],
            "tenant_name": tenant["name"],
            "tenant_slug": tenant["slug"],
            "schema": tenant["schema_name"],
        }
    )
    return {"access_token": token, "token_type": "bearer"}


def get_tenant_settings(db: Session, tenant_id: int, tenant_name: str) -> dict[str, Any]:
    row = db.execute(
        text(
            """
            SELECT storefront_name, logo_url, primary_color, accent_color, support_email, support_phone,
                   currency, storefront_domain, hero_title, hero_subtitle
            FROM public.tenant_settings
            WHERE tenant_id=:tenant_id
            """
        ),
        {"tenant_id": tenant_id},
    ).mappings().first()
    if not row:
        return {
            "storefront_name": tenant_name,
            "logo_url": None,
            "primary_color": "#111111",
            "accent_color": "#eef2f7",
            "support_email": None,
            "support_phone": None,
            "currency": "INR",
            "storefront_domain": None,
            "hero_title": f"{tenant_name} Store",
            "hero_subtitle": "Welcome to your storefront.",
        }
    return dict(row)


def upsert_tenant_settings(db: Session, tenant_id: int, tenant_name: str, payload: TenantSettingsIn) -> dict[str, Any]:
    storefront_name = payload.storefront_name or tenant_name
    hero_title = payload.hero_title or f"{storefront_name} Store"
    hero_subtitle = payload.hero_subtitle or "Welcome to your storefront."
    settings_row = db.execute(
        text(
            """
            INSERT INTO public.tenant_settings(
              tenant_id, storefront_name, logo_url, primary_color, accent_color,
              support_email, support_phone, currency, storefront_domain, hero_title, hero_subtitle
            )
            VALUES (
              :tenant_id, :storefront_name, :logo_url, :primary_color, :accent_color,
              :support_email, :support_phone, :currency, :storefront_domain, :hero_title, :hero_subtitle
            )
            ON CONFLICT (tenant_id)
            DO UPDATE SET
              storefront_name=EXCLUDED.storefront_name,
              logo_url=EXCLUDED.logo_url,
              primary_color=EXCLUDED.primary_color,
              accent_color=EXCLUDED.accent_color,
              support_email=EXCLUDED.support_email,
              support_phone=EXCLUDED.support_phone,
              currency=EXCLUDED.currency,
              storefront_domain=EXCLUDED.storefront_domain,
              hero_title=EXCLUDED.hero_title,
              hero_subtitle=EXCLUDED.hero_subtitle,
              updated_at=NOW()
            RETURNING storefront_name, logo_url, primary_color, accent_color, support_email, support_phone,
                      currency, storefront_domain, hero_title, hero_subtitle
            """
        ),
        {
            "tenant_id": tenant_id,
            "storefront_name": storefront_name,
            "logo_url": payload.logo_url,
            "primary_color": payload.primary_color,
            "accent_color": payload.accent_color,
            "support_email": str(payload.support_email) if payload.support_email else None,
            "support_phone": payload.support_phone,
            "currency": payload.currency.upper(),
            "storefront_domain": payload.storefront_domain,
            "hero_title": hero_title,
            "hero_subtitle": hero_subtitle,
        },
    ).mappings().first()
    return dict(settings_row)


def ensure_tenant_schema_objects(db: Session, schema: str) -> None:
    db.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}"'))
    db.execute(
        text(
            f"""
            CREATE TABLE IF NOT EXISTS "{schema}".users (
              id BIGSERIAL PRIMARY KEY,
              email VARCHAR(255) UNIQUE NOT NULL,
              password_hash VARCHAR(255) NOT NULL,
              full_name VARCHAR(120) NOT NULL DEFAULT 'User',
              role VARCHAR(32) NOT NULL DEFAULT 'customer',
              created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    db.execute(text(f'ALTER TABLE "{schema}".users ADD COLUMN IF NOT EXISTS full_name VARCHAR(120)'))
    db.execute(text(f'ALTER TABLE "{schema}".users ADD COLUMN IF NOT EXISTS role VARCHAR(32)'))
    db.execute(text(f"UPDATE \"{schema}\".users SET role='seller' WHERE role='admin'"))
    db.execute(text(f"UPDATE \"{schema}\".users SET role='customer' WHERE role IS NULL"))
    db.execute(text(f"UPDATE \"{schema}\".users SET full_name='User' WHERE full_name IS NULL OR full_name=''"))
    db.execute(
        text(
            f"""
            CREATE TABLE IF NOT EXISTS "{schema}".products (
              id BIGSERIAL PRIMARY KEY,
              name VARCHAR(150) NOT NULL,
              description TEXT,
              price NUMERIC(10,2) NOT NULL,
              stock INT NOT NULL DEFAULT 0,
              created_at TIMESTAMP NOT NULL DEFAULT NOW(),
              updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    db.execute(
        text(
            f"""
            CREATE TABLE IF NOT EXISTS "{schema}".orders (
              id BIGSERIAL PRIMARY KEY,
              user_id BIGINT NOT NULL,
              status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
              total_amount NUMERIC(10,2) NOT NULL,
              items JSONB NOT NULL,
              created_at TIMESTAMP NOT NULL DEFAULT NOW(),
              updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
            """
        )
    )


@app.on_event("startup")
def startup() -> None:
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS public.tenants (
                  id BIGSERIAL PRIMARY KEY,
                  name VARCHAR(120) NOT NULL,
                  slug VARCHAR(80) UNIQUE NOT NULL,
                  schema_name VARCHAR(63) UNIQUE NOT NULL,
                  created_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
                """
            )
        )
        conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS public.tenant_settings (
                  id BIGSERIAL PRIMARY KEY,
                  tenant_id BIGINT UNIQUE NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
                  storefront_name VARCHAR(120) NOT NULL,
                  logo_url TEXT,
                  primary_color VARCHAR(7) NOT NULL DEFAULT '#111111',
                  accent_color VARCHAR(7) NOT NULL DEFAULT '#eef2f7',
                  support_email VARCHAR(255),
                  support_phone VARCHAR(40),
                  currency VARCHAR(10) NOT NULL DEFAULT 'INR',
                  storefront_domain VARCHAR(255),
                  hero_title VARCHAR(255),
                  hero_subtitle TEXT,
                  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
                  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
                """
            )
        )


@app.get("/health")
def health() -> dict:
    return {"service": settings.service_name, "status": "ok", "ts": datetime.utcnow().isoformat()}


@app.post("/tenants/signup")
def tenant_signup(payload: TenantSignupIn, db: Session = Depends(db_session)) -> dict:
    schema = validate_schema_name(f"tenant_{payload.tenant_slug.replace('-', '_')}")
    seller_email = resolve_seller_email(payload)

    try:
        tenant = db.execute(
            text(
                """
                INSERT INTO public.tenants(name, slug, schema_name)
                VALUES (:name, :slug, :schema)
                RETURNING id, name, slug, schema_name
                """
            ),
            {"name": payload.tenant_name, "slug": payload.tenant_slug, "schema": schema},
        ).mappings().first()
        ensure_tenant_schema_objects(db, schema)
        db.execute(
            text(
                f"""
                INSERT INTO "{schema}".users(email, password_hash, full_name, role)
                VALUES (:email, :password_hash, :full_name, 'seller')
                """
            ),
            {
                "email": seller_email,
                "password_hash": pwd_ctx.hash(payload.password),
                "full_name": payload.seller_name,
            },
        )
        upsert_tenant_settings(db, int(tenant["id"]), payload.tenant_name, TenantSettingsIn())
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Tenant slug already exists") from exc

    return {
        "message": "tenant created",
        "tenant_slug": payload.tenant_slug,
        "schema": schema,
        "seller_email": seller_email,
        "seller_role": "seller",
    }


@app.post("/customers/signup")
def customer_signup(payload: CustomerSignupIn, db: Session = Depends(db_session)) -> dict:
    tenant = get_tenant_by_slug(db, payload.tenant_slug)

    try:
        ensure_tenant_schema_objects(db, tenant["schema_name"])
        set_tenant_schema(db, tenant["schema_name"])
        customer = db.execute(
            text(
                """
                INSERT INTO users(email, password_hash, full_name, role)
                VALUES (:email, :password_hash, :full_name, 'customer')
                RETURNING id, email, full_name, role, created_at
                """
            ),
            {
                "email": str(payload.email),
                "password_hash": pwd_ctx.hash(payload.password),
                "full_name": payload.full_name,
            },
        ).mappings().first()
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Customer email already exists for this tenant") from exc
    finally:
        reset_schema(db)

    return {"message": "customer created", "tenant_slug": tenant["slug"], "user": dict(customer)}


def create_tenant_store(payload: TenantProvisionIn, db: Session) -> dict:
    schema = validate_schema_name(f"tenant_{payload.tenant_slug.replace('-', '_')}")
    seller_email = resolve_seller_email_for_provision(payload)

    try:
        tenant = db.execute(
            text(
                """
                INSERT INTO public.tenants(name, slug, schema_name)
                VALUES (:name, :slug, :schema)
                RETURNING id, name, slug, schema_name
                """
            ),
            {"name": payload.tenant_name, "slug": payload.tenant_slug, "schema": schema},
        ).mappings().first()
        ensure_tenant_schema_objects(db, schema)

        seller_user = db.execute(
            text(
                f"""
                INSERT INTO "{schema}".users(email, password_hash, full_name, role)
                VALUES (:email, :password_hash, :full_name, 'seller')
                RETURNING id, email, full_name, role, created_at
                """
            ),
            {
                "email": seller_email,
                "password_hash": pwd_ctx.hash(payload.password),
                "full_name": payload.seller_name,
            },
        ).mappings().first()

        seeded_products: list[dict[str, Any]] = []
        for product in payload.sample_products:
            created_product = db.execute(
                text(
                    f"""
                    INSERT INTO "{schema}".products(name, description, price, stock)
                    VALUES (:name, :description, :price, :stock)
                    RETURNING id, name, description, price::text, stock
                    """
                ),
                {
                    "name": product.name,
                    "description": product.description,
                    "price": product.price,
                    "stock": product.stock,
                },
            ).mappings().first()
            seeded_products.append(dict(created_product))

        settings_row = upsert_tenant_settings(db, int(tenant["id"]), payload.tenant_name, payload.settings)
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Tenant slug already exists") from exc

    storefront_url = (
        f"https://{settings_row['storefront_domain']}"
        if settings_row.get("storefront_domain")
        else f"{settings.frontend_base_url.rstrip('/')}/?tenant={tenant['slug']}"
    )
    admin_url = f"{settings.frontend_base_url.rstrip('/')}/admin.html"

    return {
        "message": "tenant provisioned",
        "tenant": {
            "id": int(tenant["id"]),
            "name": tenant["name"],
            "slug": tenant["slug"],
            "schema": tenant["schema_name"],
        },
        "seller_admin": dict(seller_user),
        "storefront_settings": settings_row,
        "seeded_products": seeded_products,
        "delivery": {
            "storefront_url": storefront_url,
            "admin_url": admin_url,
            "seller_login_email": seller_email,
        },
    }


@app.post("/tenants/provision")
def tenant_provision(
    payload: TenantProvisionIn,
    _: None = Depends(require_provisioning_key),
    db: Session = Depends(db_session),
) -> dict:
    return create_tenant_store(payload, db)


@app.get("/tenants/{tenant_slug}/settings")
def tenant_settings(tenant_slug: str, db: Session = Depends(db_session)) -> dict:
    tenant = get_tenant_by_slug(db, tenant_slug)
    settings_row = get_tenant_settings(db, int(tenant["id"]), tenant["name"])
    return {"tenant_slug": tenant["slug"], "settings": settings_row}


@app.put("/tenants/{tenant_slug}/settings")
def update_tenant_settings(
    tenant_slug: str,
    payload: TenantSettingsIn,
    _: None = Depends(require_provisioning_key),
    db: Session = Depends(db_session),
) -> dict:
    tenant = get_tenant_by_slug(db, tenant_slug)
    settings_row = upsert_tenant_settings(db, int(tenant["id"]), tenant["name"], payload)
    db.commit()
    return {"message": "settings updated", "tenant_slug": tenant["slug"], "settings": settings_row}


@app.post("/tenants/{tenant_slug}/seller/reset-password")
def reset_seller_password(
    tenant_slug: str,
    payload: SellerPasswordResetIn,
    _: None = Depends(require_provisioning_key),
    db: Session = Depends(db_session),
) -> dict:
    tenant = get_tenant_by_slug(db, tenant_slug)
    schema = validate_schema_name(tenant["schema_name"])
    ensure_tenant_schema_objects(db, schema)
    try:
        set_tenant_schema(db, schema)
        seller = db.execute(
            text(
                """
                UPDATE users
                SET password_hash=:password_hash
                WHERE email=:email AND role='seller'
                RETURNING id, email, role
                """
            ),
            {
                "email": str(payload.email),
                "password_hash": pwd_ctx.hash(payload.password),
            },
        ).mappings().first()
        if not seller:
            raise HTTPException(status_code=404, detail="Seller user not found for tenant")
        db.commit()
    finally:
        reset_schema(db)

    return {"message": "seller password reset", "tenant_slug": tenant["slug"], "seller": dict(seller)}


@app.post("/auth/token")
def login_for_access_token(
    tenant_slug: str | None = Form(default=None),
    username: str = Form(...),
    password: str = Form(...),
    client_id: str | None = Form(default=None),
    db: Session = Depends(db_session),
) -> dict:
    tenant_slug = tenant_slug or client_id
    if not tenant_slug:
        raise HTTPException(
            status_code=422,
            detail="tenant_slug is required. In Swagger Authorize, put the tenant slug in client_id.",
        )
    return issue_access_token(db, tenant_slug, username, password)


@app.post("/auth/login")
def login_with_json(payload: LoginIn, db: Session = Depends(db_session)) -> dict:
    return issue_access_token(db, payload.tenant_slug, str(payload.username), payload.password)


@app.post("/auth/token/json")
def login_token_json(payload: LoginIn, db: Session = Depends(db_session)) -> dict:
    return issue_access_token(db, payload.tenant_slug, str(payload.username), payload.password)


@app.post("/platform/auth/login")
def platform_login(payload: PlatformLoginIn) -> dict:
    if str(payload.email).lower() != settings.platform_admin_email.lower() or payload.password != settings.platform_admin_password:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid platform admin credentials")

    token = create_access_token(
        {
            "sub": "platform_admin",
            "email": settings.platform_admin_email,
            "role": "platform_admin",
            "scope": "platform",
        }
    )
    return {"access_token": token, "token_type": "bearer"}


@app.get("/platform/tenants")
def platform_list_tenants(
    _: dict = Depends(get_platform_admin_payload),
    db: Session = Depends(db_session),
) -> dict:
    rows = db.execute(
        text(
            """
            SELECT
              t.id,
              t.name,
              t.slug,
              t.schema_name,
              t.created_at,
              ts.storefront_name,
              ts.logo_url,
              ts.primary_color,
              ts.accent_color,
              ts.support_email,
              ts.support_phone,
              ts.currency,
              ts.storefront_domain
            FROM public.tenants t
            LEFT JOIN public.tenant_settings ts ON ts.tenant_id = t.id
            ORDER BY t.id DESC
            """
        )
    ).mappings().all()
    return {"items": [dict(row) for row in rows]}


@app.post("/platform/tenants/provision")
def platform_provision_tenant(
    payload: TenantProvisionIn,
    _: dict = Depends(get_platform_admin_payload),
    db: Session = Depends(db_session),
) -> dict:
    return create_tenant_store(payload, db)


@app.get("/auth/me")
def me(token_data: dict = Depends(get_token_payload)) -> dict:
    return token_data
