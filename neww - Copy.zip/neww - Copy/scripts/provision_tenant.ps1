param(
  [string]$BaseUrlTenant = "http://127.0.0.1:8001",
  [string]$TenantName = "Nike",
  [string]$TenantSlug = "nike",
  [string]$SellerName = "Nike Owner",
  [string]$SellerEmail = "seller@nike.com",
  [string]$SellerPassword = "Password123!",
  [string]$PrimaryColor = "#111111",
  [string]$AccentColor = "#eef2f7",
  [string]$Currency = "INR",
  [string]$StorefrontDomain = "",
  [string]$ProvisioningApiKey = "",
  [switch]$AllowExisting,
  [switch]$ResetExistingSellerPassword
)

$ErrorActionPreference = "Stop"

function Invoke-Json {
  param([string]$Method, [string]$Url, $Body = $null, [hashtable]$Headers = @{})
  if ($Body -ne $null) {
    return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers -Body ($Body | ConvertTo-Json -Depth 10) -ContentType "application/json"
  }
  return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers
}

$headers = @{}
if ($ProvisioningApiKey) {
  $headers["x-provision-key"] = $ProvisioningApiKey
}

$payload = @{
  tenant_name = $TenantName
  tenant_slug = $TenantSlug
  seller_name = $SellerName
  seller_email = $SellerEmail
  password = $SellerPassword
  settings = @{
    storefront_name = $TenantName
    primary_color = $PrimaryColor
    accent_color = $AccentColor
    currency = $Currency
    storefront_domain = if ($StorefrontDomain) { $StorefrontDomain } else { $null }
    hero_title = "$TenantName Store"
    hero_subtitle = "Welcome to the official $TenantName storefront."
    support_email = $SellerEmail
  }
  sample_products = @(
    @{
      name = "$TenantName Starter Product"
      description = "Replace this sample with your real catalog."
      price = 999.00
      stock = 25
    }
  )
}

Write-Host "Provisioning tenant $TenantSlug ..."
try {
  $result = Invoke-Json -Method POST -Url "$BaseUrlTenant/tenants/provision" -Body $payload -Headers $headers
  $mode = "created"
} catch {
  $responseText = ""
  if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
    $responseText = [string]$_.ErrorDetails.Message
  }
  if ($_.Exception.Response) {
    try {
      $stream = $_.Exception.Response.GetResponseStream()
      $reader = New-Object System.IO.StreamReader($stream)
      $streamText = $reader.ReadToEnd()
      if ($streamText) {
        $responseText = $streamText
      }
    } catch {}
  }

  if ($AllowExisting -and ($responseText -like '*Tenant slug already exists*')) {
    Write-Host "Tenant exists. Updating settings only for $TenantSlug ..."
    $settingsResult = Invoke-Json -Method PUT -Url "$BaseUrlTenant/tenants/$TenantSlug/settings" -Body $payload.settings -Headers $headers
    if ($ResetExistingSellerPassword) {
      Write-Host "Resetting existing seller password for $SellerEmail ..."
      Invoke-Json -Method POST -Url "$BaseUrlTenant/tenants/$TenantSlug/seller/reset-password" -Body @{
        email = $SellerEmail
        password = $SellerPassword
      } -Headers $headers | Out-Null
    }
    $mode = "updated"
    $result = @{
      tenant = @{
        slug = $TenantSlug
        schema = "tenant_$TenantSlug"
      }
      delivery = @{
        storefront_url = if ($StorefrontDomain) { "https://$StorefrontDomain" } else { "http://localhost:3000/?tenant=$TenantSlug" }
        admin_url = "http://localhost:3000/admin.html"
        seller_login_email = $SellerEmail
      }
      storefront_settings = $settingsResult.settings
    }
  } else {
    throw
  }
}

Write-Host ""
Write-Host "Provisioning complete ($mode)."
Write-Host "Storefront URL : $($result.delivery.storefront_url)"
Write-Host "Admin URL      : $($result.delivery.admin_url)"
Write-Host "Seller Email   : $($result.delivery.seller_login_email)"
Write-Host "Tenant Schema  : $($result.tenant.schema)"
Write-Host ""
Write-Host "Save these values in your client handoff document."
