# Client Storefront Handoff

## Client Details
- Client Name:
- Tenant Slug:
- Provisioned On:
- Account Manager:

## Access Links
- Storefront URL:
- Admin URL:
- API Status URL: `http://<tenant-user-host>/health`

## Admin Credentials
- Seller Email:
- Temporary Password:
- Password Reset Required By:

## Branding Settings
- Storefront Name:
- Primary Color:
- Accent Color:
- Currency:
- Logo URL:
- Support Email:
- Support Phone:

## Operational Notes
- Tenant schema:
- Backup policy:
- Monitoring/alerts owner:
- SLA tier:

## Client Quick Start
1. Log in to Admin URL.
2. Change temporary password immediately.
3. Update logo, hero text, and support details.
4. Replace sample products with real catalog.
5. Place one test order end-to-end.
