param(
  [string]$BaseUrlTenant = "http://127.0.0.1:8001",
  [string]$BaseUrlProduct = "http://127.0.0.1:8002",
  [string]$BaseUrlOrder = "http://127.0.0.1:8003"
)

function Invoke-Json {
  param([string]$Method, [string]$Url, $Body = $null, [hashtable]$Headers = @{})
  if ($Body -ne $null) {
    return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers -Body ($Body | ConvertTo-Json -Depth 8) -ContentType "application/json"
  }
  return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers
}

function Invoke-Form {
  param([string]$Url, [hashtable]$Body, [hashtable]$Headers = @{})
  $encoded = ($Body.GetEnumerator() | ForEach-Object {
    "{0}={1}" -f [System.Uri]::EscapeDataString([string]$_.Key), [System.Uri]::EscapeDataString([string]$_.Value)
  }) -join "&"
  return Invoke-RestMethod -Method POST -Uri $Url -Headers $Headers -Body $encoded -ContentType "application/x-www-form-urlencoded"
}

Write-Host "Creating Nike and Adidas tenants..."
$nikeSignup = Invoke-Json -Method POST -Url "$BaseUrlTenant/tenants/signup" -Body @{
  tenant_name = "Nike"
  tenant_slug = "nike"
  seller_name = "Nike Owner"
  seller_email = "seller@nike.com"
  password = "Password123!"
}
$adidasSignup = Invoke-Json -Method POST -Url "$BaseUrlTenant/tenants/signup" -Body @{
  tenant_name = "Adidas"
  tenant_slug = "adidas"
  seller_name = "Adidas Owner"
  seller_email = "seller@adidas.com"
  password = "Password123!"
}

Write-Host "Logging in tenants..."
$nikeToken = (Invoke-Form -Url "$BaseUrlTenant/auth/token" -Body @{
  tenant_slug = "nike"
  username = "seller@nike.com"
  password = "Password123!"
}).access_token

$adidasToken = (Invoke-Form -Url "$BaseUrlTenant/auth/token" -Body @{
  tenant_slug = "adidas"
  username = "seller@adidas.com"
  password = "Password123!"
}).access_token

$nikeHeaders = @{ Authorization = "Bearer $nikeToken" }
$adidasHeaders = @{ Authorization = "Bearer $adidasToken" }

Write-Host "Creating one Nike customer..."
Invoke-Json -Method POST -Url "$BaseUrlTenant/customers/signup" -Body @{
  tenant_slug = "nike"
  full_name = "Nike Buyer"
  email = "buyer@nike.com"
  password = "Password123!"
} | Out-Null

$nikeCustomerToken = (Invoke-Form -Url "$BaseUrlTenant/auth/token" -Body @{
  tenant_slug = "nike"
  username = "buyer@nike.com"
  password = "Password123!"
}).access_token

$nikeCustomerHeaders = @{ Authorization = "Bearer $nikeCustomerToken" }

Write-Host "Creating one Nike product..."
$nikeProduct = Invoke-Json -Method POST -Url "$BaseUrlProduct/products" -Headers $nikeHeaders -Body @{
  name = "Nike Air"
  description = "Nike test shoe"
  price = 120.50
  stock = 10
}

Write-Host "Checking Adidas product list is isolated..."
$adidasProducts = Invoke-Json -Method GET -Url "$BaseUrlProduct/products" -Headers $adidasHeaders
if ($adidasProducts.items.Count -gt 0) {
  throw "Isolation failed: Adidas sees Nike data"
}

Write-Host "Nike customer cart + checkout flow..."
$nikeCustomerProducts = Invoke-Json -Method GET -Url "$BaseUrlProduct/products" -Headers $nikeCustomerHeaders
if ($nikeCustomerProducts.items.Count -eq 0) {
  throw "Nike customer cannot see Nike products"
}

Invoke-Json -Method POST -Url "$BaseUrlOrder/cart/add" -Headers $nikeCustomerHeaders -Body @{
  product_id = $nikeProduct.id
  quantity = 2
} | Out-Null

$checkout = Invoke-Json -Method POST -Url "$BaseUrlOrder/orders/checkout" -Headers $nikeCustomerHeaders
Write-Host "Order created:" ($checkout.order.id)

Write-Host "Smoke test completed."
