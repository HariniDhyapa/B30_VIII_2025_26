# Multi-Tenant E-Commerce Platform (FastAPI + PostgreSQL Schemas)

Production-style, cost-free microservices architecture for multi-tenant e-commerce with strict tenant isolation using PostgreSQL schemas.

## Architecture

- `tenant-user` service: tenant onboarding, seller/customer auth, JWT + OAuth2
- `product` service: product CRUD APIs + Redis caching
- `order` service: cart (Redis), checkout, order history, async updates
- `payment` service: consumes `order.created`, mock processing, emits `payment.succeeded`
- `frontend` service: lightweight browser UI to verify seller/customer flows against the APIs
- Shared infra: PostgreSQL, Redis, RabbitMQ

## Tenant Isolation Model

- Single PostgreSQL instance
- `public.tenants` tracks tenants
- Each tenant gets schema: `tenant_<slug>`
- Business tables (`users`, `products`, `orders`, `payments`) exist per tenant schema
- JWT includes `schema`, every request sets PostgreSQL `search_path` to that schema

## End Users

- Sellers (tenants): small business owners with seller accounts that manage products, orders, and revenue for their own shop
- Customers: shoppers who sign up under a specific tenant storefront and place orders in that tenant's schema
- One backend supports many shops, while JWT claims carry the tenant context needed to keep every shop isolated

## Repository Structure

```text
common/
services/
  tenant-user/
  product/
  order/
  payment/
k8s/
  base/
  minikube/
.github/workflows/
terraform/aws-free-tier/
scripts/
```

## Local Run (Docker Compose)

1. Copy env:

```bash
cp .env.example .env
```

2. Build + run:

```bash
docker compose up --build -d
```

3. Service endpoints:

- Tenant-User: `http://localhost:8001`
- Product: `http://localhost:8002`
- Order: `http://localhost:8003`
- Payment: `http://localhost:8004`
- Frontend test console: `http://localhost:3000`
- RabbitMQ UI: `http://localhost:15672` (`guest/guest`)

## Quick Test Flow (Nike + Adidas isolation)

Use [scripts/smoke_test.ps1](scripts/smoke_test.ps1).

It validates:
- tenant creation for `nike` and `adidas`
- independent JWTs per tenant
- product CRUD isolation (Nike data not visible in Adidas)
- cart -> checkout -> payment event flow

You can also verify the same flows manually in the browser through the frontend test console.

## Core APIs

### Tenant-User Service
- `POST /tenants/signup`
- `POST /customers/signup`
- `POST /auth/token`
- `GET /auth/me`

### Product Service
- `POST /products`
- `GET /products`
- `GET /products/{id}`
- `PATCH /products/{id}`
- `DELETE /products/{id}`

### Order Service
- `POST /cart/add`
- `DELETE /cart/remove/{product_id}`
- `GET /cart`
- `POST /orders/checkout`
- `GET /orders`

### Payment Service
- `GET /health`
- Background consumer for `order.created`

## Kubernetes (Minikube)

1. Build/push images (or `minikube image load`):

```bash
docker build -f services/tenant-user/Dockerfile -t varshatogari/tenant-user:v1 .
docker build -f services/product/Dockerfile -t varshatogari/product:v1 .
docker build -f services/order/Dockerfile -t varshatogari/order:v1 .
docker build -f services/payment/Dockerfile -t varshatogari/payment:v1 .
```

2. Deploy:

```bash
kubectl apply -k k8s/minikube
```

3. Verify 8 app pods (2 replicas x 4 services):

```bash
kubectl get pods -n ecommerce
```

## CI/CD

GitHub Actions workflow: `.github/workflows/ci.yml`
- lint (`ruff`)
- build all service images, including the frontend verifier

## Free-Tier Notes

- Local stack (Docker + Minikube): `$0`
- GitHub Actions free minutes: up to 2000/min per month (account-dependent)
- Optional AWS EC2 `t2.micro` / `t3.micro` deployment can stay in free-tier limits with low usage

## Resume Bullet Ideas

- Built a schema-isolated multi-tenant e-commerce platform with FastAPI microservices.
- Implemented JWT tenant context with OAuth2 login, seller/customer separation, Redis caching/carts, and RabbitMQ event-driven order-payment orchestration.
- Containerized and deployed locally on Docker Compose and Kubernetes (Minikube) with CI pipeline on GitHub Actions.
