import json
import random
import threading
import time
from datetime import datetime

import pika
from fastapi import FastAPI
from sqlalchemy import text

from common.auth import validate_schema_name
from common.config import settings
from common.cors import apply_cors
from common.db import SessionLocal, reset_schema, set_tenant_schema
from common.rabbitmq import publish_event

app = FastAPI(title="Payment Service", version="1.0.0")
apply_cors(app)


def consume_orders() -> None:
    while True:
        try:
            connection = pika.BlockingConnection(pika.URLParameters(settings.rabbitmq_url))
            channel = connection.channel()
            channel.exchange_declare(exchange="commerce", exchange_type="topic", durable=True)
            channel.queue_declare(queue="payment.order.created", durable=True)
            channel.queue_bind(exchange="commerce", queue="payment.order.created", routing_key="order.created")

            def callback(ch, method, properties, body):
                payload = json.loads(body.decode("utf-8"))
                schema = validate_schema_name(payload["schema"])
                order_id = int(payload["order_id"])
                amount = payload["amount"]

                # Mock payment processing latency.
                time.sleep(1)
                success = random.random() <= settings.payment_success_rate

                db = SessionLocal()
                try:
                    set_tenant_schema(db, schema)
                    db.execute(
                        text(
                            """
                            CREATE TABLE IF NOT EXISTS payments (
                              id BIGSERIAL PRIMARY KEY,
                              order_id BIGINT NOT NULL,
                              status VARCHAR(32) NOT NULL,
                              amount NUMERIC(10,2) NOT NULL,
                              created_at TIMESTAMP NOT NULL DEFAULT NOW()
                            )
                            """
                        )
                    )
                    db.execute(
                        text("INSERT INTO payments(order_id, status, amount) VALUES (:order_id, :status, :amount)"),
                        {"order_id": order_id, "status": "SUCCEEDED" if success else "FAILED", "amount": amount},
                    )
                    db.commit()
                    reset_schema(db)

                    if success:
                        publish_event(
                            "payment.succeeded",
                            {
                                "order_id": order_id,
                                "schema": schema,
                                "tenant_id": payload["tenant_id"],
                                "tenant_slug": payload["tenant_slug"],
                            },
                        )

                    ch.basic_ack(delivery_tag=method.delivery_tag)
                except Exception:
                    db.rollback()
                    ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
                finally:
                    db.close()

            channel.basic_qos(prefetch_count=10)
            channel.basic_consume(queue="payment.order.created", on_message_callback=callback)
            channel.start_consuming()
        except Exception:
            time.sleep(3)


@app.on_event("startup")
def startup() -> None:
    t = threading.Thread(target=consume_orders, daemon=True)
    t.start()


@app.get("/health")
def health() -> dict:
    return {"service": settings.service_name, "status": "ok", "ts": datetime.utcnow().isoformat()}
