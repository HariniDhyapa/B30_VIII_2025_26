import json
import threading
import time
from datetime import datetime
from decimal import Decimal
from typing import Generator

import httpx
import pika
from fastapi import Depends, FastAPI, Header, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from common.auth import decode_access_token, validate_schema_name
from common.config import settings
from common.cors import apply_cors
from common.db import SessionLocal, reset_schema, set_tenant_schema
from common.rabbitmq import publish_event
from common.redis_client import get_redis_client

app = FastAPI(title="Order Service", version="1.0.0")
apply_cors(app)
redis_client = get_redis_client()
product_service_url = "http://product:8000"


class CartItemIn(BaseModel):
    product_id: int
    quantity: int = Field(ge=1)


def db_session() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def tenant_context(authorization: str = Header(default="")) -> dict:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing bearer token")
    try:
        payload = decode_access_token(authorization.split(" ", 1)[1])
        payload["schema"] = validate_schema_name(payload["schema"])
        payload["token"] = authorization
        return payload
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token") from exc


def cart_key(schema: str, user_id: str) -> str:
    return f"{schema}:cart:{user_id}"


def consume_payment_events() -> None:
    while True:
        try:
            connection = pika.BlockingConnection(pika.URLParameters(settings.rabbitmq_url))
            channel = connection.channel()
            channel.exchange_declare(exchange="commerce", exchange_type="topic", durable=True)
            channel.queue_declare(queue="order.payment.succeeded", durable=True)
            channel.queue_bind(exchange="commerce", queue="order.payment.succeeded", routing_key="payment.succeeded")

            def callback(ch, method, properties, body):
                payload = json.loads(body.decode("utf-8"))
                schema = validate_schema_name(payload["schema"])
                order_id = int(payload["order_id"])

                db = SessionLocal()
                try:
                    set_tenant_schema(db, schema)
                    db.execute(
                        text("UPDATE orders SET status='PAID', updated_at=NOW() WHERE id=:order_id"),
                        {"order_id": order_id},
                    )
                    db.commit()
                    reset_schema(db)
                    ch.basic_ack(delivery_tag=method.delivery_tag)
                except Exception:
                    db.rollback()
                    ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
                finally:
                    db.close()

            channel.basic_qos(prefetch_count=5)
            channel.basic_consume(queue="order.payment.succeeded", on_message_callback=callback)
            channel.start_consuming()
        except Exception:
            time.sleep(3)


@app.on_event("startup")
def startup() -> None:
    t = threading.Thread(target=consume_payment_events, daemon=True)
    t.start()


@app.get("/health")
def health() -> dict:
    return {"service": settings.service_name, "status": "ok", "ts": datetime.utcnow().isoformat()}


@app.post("/cart/add")
def add_to_cart(item: CartItemIn, ctx: dict = Depends(tenant_context)) -> dict:
    with httpx.Client(timeout=5.0) as client:
        res = client.get(
            f"{product_service_url}/products/{item.product_id}", headers={"Authorization": ctx["token"]}
        )
        if res.status_code != 200:
            raise HTTPException(status_code=400, detail="Invalid product")

    key = cart_key(ctx["schema"], ctx["sub"])
    redis_client.hincrby(key, str(item.product_id), item.quantity)
    redis_client.expire(key, 86400)
    return {"message": "added", "cart_key": key}


@app.delete("/cart/remove/{product_id}")
def remove_from_cart(product_id: int, ctx: dict = Depends(tenant_context)) -> dict:
    key = cart_key(ctx["schema"], ctx["sub"])
    redis_client.hdel(key, str(product_id))
    return {"message": "removed", "product_id": product_id}


@app.get("/cart")
def view_cart(ctx: dict = Depends(tenant_context)) -> dict:
    key = cart_key(ctx["schema"], ctx["sub"])
    cart = redis_client.hgetall(key)
    return {"items": [{"product_id": int(k), "quantity": int(v)} for k, v in cart.items()]}


@app.post("/orders/checkout")
def checkout(ctx: dict = Depends(tenant_context), db: Session = Depends(db_session)) -> dict:
    key = cart_key(ctx["schema"], ctx["sub"])
    cart = redis_client.hgetall(key)
    if not cart:
        raise HTTPException(status_code=400, detail="Cart is empty")

    items = []
    total = Decimal("0")
    with httpx.Client(timeout=5.0) as client:
        for product_id, qty in cart.items():
            res = client.get(f"{product_service_url}/products/{product_id}", headers={"Authorization": ctx["token"]})
            if res.status_code != 200:
                raise HTTPException(status_code=400, detail=f"Product {product_id} unavailable")
            product = res.json()["item"]
            quantity = int(qty)
            line_total = Decimal(product["price"]) * quantity
            total += line_total
            items.append({
                "product_id": int(product_id),
                "name": product["name"],
                "price": product["price"],
                "quantity": quantity,
                "line_total": str(line_total),
            })

    set_tenant_schema(db, ctx["schema"])
    order = db.execute(
        text(
            """
            INSERT INTO orders(user_id, status, total_amount, items)
            VALUES (:user_id, 'PENDING', :total_amount, CAST(:items AS JSONB))
            RETURNING id, user_id, status, total_amount::text, items, created_at
            """
        ),
        {"user_id": int(ctx["sub"]), "total_amount": total, "items": json.dumps(items)},
    ).mappings().first()
    db.commit()
    reset_schema(db)

    publish_event(
        "order.created",
        {
            "order_id": order["id"],
            "tenant_id": ctx["tenant_id"],
            "tenant_slug": ctx["tenant_slug"],
            "schema": ctx["schema"],
            "user_id": int(ctx["sub"]),
            "amount": order["total_amount"],
        },
    )

    redis_client.delete(key)
    return {"message": "order placed", "order": dict(order)}


@app.get("/orders")
def order_history(ctx: dict = Depends(tenant_context), db: Session = Depends(db_session)) -> dict:
    set_tenant_schema(db, ctx["schema"])
    rows = db.execute(
        text(
            "SELECT id, user_id, status, total_amount::text, items, created_at, updated_at FROM orders WHERE user_id=:uid ORDER BY id DESC"
        ),
        {"uid": int(ctx["sub"])}
    ).mappings().all()
    reset_schema(db)
    return {"items": [dict(r) for r in rows]}
