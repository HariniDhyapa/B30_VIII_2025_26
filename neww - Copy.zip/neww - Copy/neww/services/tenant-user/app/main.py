from datetime import datetime
from typing import Generator

from fastapi import Depends, FastAPI, Form, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from common.auth import create_access_token, decode_access_token, validate_schema_name
from common.config import settings
from common.cors import apply_cors
from common.db import SessionLocal, engine, reset_schema, set_tenant_schema

app = FastAPI(title="Tenant-User Service", version="1.0.0")
apply_cors(app)
pwd_ctx = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token")


class TenantSignupIn(BaseModel):
    tenant_name: str = Field(min_length=2)
    tenant_slug: str = Field(pattern=r"^[a-z0-9-]{2,40}$")
    seller_name: str = Field(min_length=2, max_length=120)
    seller_email: EmailStr | None = None
    admin_email: EmailStr | None = None
    password: str = Field(min_length=8)


class CustomerSignupIn(BaseModel):
    tenant_slug: str
    email: EmailStr
    password: str = Field(min_length=8)
    full_name: str = Field(min_length=2, max_length=120)


def db_session() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_token_payload(token: str = Depends(oauth2_scheme)) -> dict:
    try:
        return decode_access_token(token)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(exc)) from exc


def resolve_seller_email(payload: TenantSignupIn) -> str:
    seller_email = payload.seller_email or payload.admin_email
    if not seller_email:
        raise HTTPException(status_code=422, detail="seller_email is required")
    return str(seller_email)


def get_tenant_by_slug(db: Session, tenant_slug: str) -> dict:
    tenant = db.execute(
        text("SELECT id, name, slug, schema_name FROM public.tenants WHERE slug=:slug"),
        {"slug": tenant_slug},
    ).mappings().first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return dict(tenant)


def ensure_tenant_schema_objects(db: Session, schema: str) -> None:
    db.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}"'))
    db.execute(
        text(
            f"""
            CREATE TABLE IF NOT EXISTS "{schema}".users (
              id BIGSERIAL PRIMARY KEY,
              email VARCHAR(255) UNIQUE NOT NULL,
              password_hash VARCHAR(255) NOT NULL,
              full_name VARCHAR(120) NOT NULL DEFAULT 'User',
              role VARCHAR(32) NOT NULL DEFAULT 'customer',
              created_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    db.execute(text(f'ALTER TABLE "{schema}".users ADD COLUMN IF NOT EXISTS full_name VARCHAR(120)'))
    db.execute(text(f'ALTER TABLE "{schema}".users ADD COLUMN IF NOT EXISTS role VARCHAR(32)'))
    db.execute(text(f"UPDATE \"{schema}\".users SET role='seller' WHERE role='admin'"))
    db.execute(text(f"UPDATE \"{schema}\".users SET role='customer' WHERE role IS NULL"))
    db.execute(text(f"UPDATE \"{schema}\".users SET full_name='User' WHERE full_name IS NULL OR full_name=''"))
    db.execute(
        text(
            f"""
            CREATE TABLE IF NOT EXISTS "{schema}".products (
              id BIGSERIAL PRIMARY KEY,
              name VARCHAR(150) NOT NULL,
              description TEXT,
              price NUMERIC(10,2) NOT NULL,
              stock INT NOT NULL DEFAULT 0,
              created_at TIMESTAMP NOT NULL DEFAULT NOW(),
              updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    db.execute(
        text(
            f"""
            CREATE TABLE IF NOT EXISTS "{schema}".orders (
              id BIGSERIAL PRIMARY KEY,
              user_id BIGINT NOT NULL,
              status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
              total_amount NUMERIC(10,2) NOT NULL,
              items JSONB NOT NULL,
              created_at TIMESTAMP NOT NULL DEFAULT NOW(),
              updated_at TIMESTAMP NOT NULL DEFAULT NOW()
            )
            """
        )
    )


@app.on_event("startup")
def startup() -> None:
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS public.tenants (
                  id BIGSERIAL PRIMARY KEY,
                  name VARCHAR(120) NOT NULL,
                  slug VARCHAR(80) UNIQUE NOT NULL,
                  schema_name VARCHAR(63) UNIQUE NOT NULL,
                  created_at TIMESTAMP NOT NULL DEFAULT NOW()
                )
                """
            )
        )


@app.get("/health")
def health() -> dict:
    return {"service": settings.service_name, "status": "ok", "ts": datetime.utcnow().isoformat()}


@app.post("/tenants/signup")
def tenant_signup(payload: TenantSignupIn, db: Session = Depends(db_session)) -> dict:
    schema = validate_schema_name(f"tenant_{payload.tenant_slug.replace('-', '_')}")
    seller_email = resolve_seller_email(payload)

    try:
        db.execute(
            text("INSERT INTO public.tenants(name, slug, schema_name) VALUES (:name, :slug, :schema)"),
            {"name": payload.tenant_name, "slug": payload.tenant_slug, "schema": schema},
        )
        ensure_tenant_schema_objects(db, schema)
        db.execute(
            text(
                f"""
                INSERT INTO "{schema}".users(email, password_hash, full_name, role)
                VALUES (:email, :password_hash, :full_name, 'seller')
                """
            ),
            {
                "email": seller_email,
                "password_hash": pwd_ctx.hash(payload.password),
                "full_name": payload.seller_name,
            },
        )
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Tenant slug already exists") from exc

    return {
        "message": "tenant created",
        "tenant_slug": payload.tenant_slug,
        "schema": schema,
        "seller_email": seller_email,
        "seller_role": "seller",
    }


@app.post("/customers/signup")
def customer_signup(payload: CustomerSignupIn, db: Session = Depends(db_session)) -> dict:
    tenant = get_tenant_by_slug(db, payload.tenant_slug)

    try:
        ensure_tenant_schema_objects(db, tenant["schema_name"])
        set_tenant_schema(db, tenant["schema_name"])
        customer = db.execute(
            text(
                """
                INSERT INTO users(email, password_hash, full_name, role)
                VALUES (:email, :password_hash, :full_name, 'customer')
                RETURNING id, email, full_name, role, created_at
                """
            ),
            {
                "email": str(payload.email),
                "password_hash": pwd_ctx.hash(payload.password),
                "full_name": payload.full_name,
            },
        ).mappings().first()
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Customer email already exists for this tenant") from exc
    finally:
        reset_schema(db)

    return {"message": "customer created", "tenant_slug": tenant["slug"], "user": dict(customer)}


@app.post("/auth/token")
def login_for_access_token(
    tenant_slug: str = Form(...),
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(db_session),
) -> dict:
    tenant = get_tenant_by_slug(db, tenant_slug)
    ensure_tenant_schema_objects(db, tenant["schema_name"])

    set_tenant_schema(db, tenant["schema_name"])
    user = db.execute(
        text("SELECT id, email, full_name, password_hash, role FROM users WHERE email=:email"),
        {"email": username},
    ).mappings().first()
    reset_schema(db)

    if not user or not pwd_ctx.verify(password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token(
        {
            "sub": str(user["id"]),
            "email": user["email"],
            "full_name": user["full_name"],
            "role": user["role"],
            "tenant_id": tenant["id"],
            "tenant_name": tenant["name"],
            "tenant_slug": tenant["slug"],
            "schema": tenant["schema_name"],
        }
    )
    return {"access_token": token, "token_type": "bearer"}


@app.get("/auth/me")
def me(token_data: dict = Depends(get_token_payload)) -> dict:
    return token_data
