const tenantDefaults = {
  nike: {
    tenant_name: "Nike",
    tenant_slug: "nike",
    seller_name: "Nike Owner",
    seller_email: "seller@nike.com",
    customer_name: "Nike Buyer",
    customer_email: "buyer@nike.com",
  },
  adidas: {
    tenant_name: "Adidas",
    tenant_slug: "adidas",
    seller_name: "Adidas Owner",
    seller_email: "seller@adidas.com",
    customer_name: "Adidas Buyer",
    customer_email: "buyer@adidas.com",
  },
};

const state = {
  activeTenant: "nike",
  sellerToken: "",
  customerToken: "",
  products: [],
  cart: [],
  search: "",
};

const $ = (id) => document.getElementById(id);

function baseUrls() {
  return {
    tenant: $("tenantApi").value.trim(),
    product: $("productApi").value.trim(),
    order: $("orderApi").value.trim(),
  };
}

function log(title, payload) {
  const stamp = new Date().toLocaleTimeString();
  const body = typeof payload === "string" ? payload : JSON.stringify(payload, null, 2);
  $("logOutput").textContent = `[${stamp}] ${title}\n${body}\n\n${$("logOutput").textContent}`;
}

function storageKey(kind) {
  return `demo:${state.activeTenant}:${kind}`;
}

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const text = await response.text();
  let data = text;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {}

  if (!response.ok) {
    throw new Error(typeof data === "string" ? data : JSON.stringify(data));
  }

  return data;
}

function authHeaders(token) {
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function formJson(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function setToken(kind, token) {
  state[kind] = token;
  $(kind).value = token;
  localStorage.setItem(storageKey(kind), token);
}

function currency(value) {
  return `Rs. ${Number(value).toFixed(2)}`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function updateHeader() {
  const defaults = tenantDefaults[state.activeTenant];
  document.body.dataset.theme = state.activeTenant;
  $("shopTitle").textContent = `${defaults.tenant_name} Store Admin`;
  $("tenantBadge").textContent = defaults.tenant_name.toUpperCase();
  $("sellerStatus").textContent = state.sellerToken ? `Logged in for ${defaults.tenant_slug}` : "Not logged in";
  $("customerStatus").textContent = state.customerToken ? `Logged in for ${defaults.tenant_slug}` : "Not logged in";
}

function filteredProducts() {
  const term = state.search.trim().toLowerCase();
  if (!term) {
    return state.products;
  }
  return state.products.filter((product) => {
    const text = `${product.name} ${product.description || ""}`.toLowerCase();
    return text.includes(term);
  });
}

function renderInventory() {
  const body = $("inventoryBody");
  if (!state.products.length) {
    body.innerHTML = '<tr><td colspan="4" class="empty-cell">No products yet.</td></tr>';
    return;
  }

  body.innerHTML = state.products
    .map(
      (product) => `
        <tr>
          <td>
            <strong>${escapeHtml(product.name)}</strong><br />
            <span class="muted">${escapeHtml(product.description || "")}</span>
          </td>
          <td>${currency(product.price)}</td>
          <td>${product.stock}</td>
          <td>
            <div class="table-actions">
              <button type="button" class="small-button secondary edit-product" data-product-id="${product.id}">Edit</button>
              <button type="button" class="small-button delete-product" data-product-id="${product.id}">Delete</button>
            </div>
          </td>
        </tr>
      `
    )
    .join("");

  document.querySelectorAll(".edit-product").forEach((button) => {
    button.addEventListener("click", () => {
      editProduct(Number(button.dataset.productId)).catch((error) => log("Edit failed", error.message));
    });
  });

  document.querySelectorAll(".delete-product").forEach((button) => {
    button.addEventListener("click", () => {
      deleteProduct(Number(button.dataset.productId)).catch((error) => log("Delete failed", error.message));
    });
  });
}

function renderMarketplace() {
  const grid = $("productGrid");
  const products = filteredProducts();
  if (!products.length) {
    grid.innerHTML = '<div class="empty-card">No products match this tenant or search.</div>';
    return;
  }

  grid.innerHTML = products
    .map(
      (product) => `
        <article class="product-card">
          <h3>${escapeHtml(product.name)}</h3>
          <p class="muted">${escapeHtml(product.description || "No description yet.")}</p>
          <div class="product-meta">
            <span>${currency(product.price)}</span>
            <span>${product.stock} in stock</span>
          </div>
          <button type="button" class="add-cart-button" data-product-id="${product.id}">Add to Cart</button>
        </article>
      `
    )
    .join("");

  document.querySelectorAll(".add-cart-button").forEach((button) => {
    button.addEventListener("click", () => {
      addToCartById(Number(button.dataset.productId)).catch((error) => log("Add to cart failed", error.message));
    });
  });
}

function renderCart() {
  const cartItems = $("cartItems");
  if (!state.cart.length) {
    cartItems.innerHTML = '<div class="empty-card">Your cart is empty.</div>';
    return;
  }

  cartItems.innerHTML = state.cart
    .map((item) => {
      const product = state.products.find((candidate) => Number(candidate.id) === Number(item.product_id));
      return `
        <div class="cart-row">
          <div>
            <strong>${escapeHtml(product?.name || `Product #${item.product_id}`)}</strong>
            <div class="muted">Quantity: ${item.quantity}</div>
          </div>
          <div>${product ? currency(product.price) : "Live price in service"}</div>
        </div>
      `;
    })
    .join("");
}

function renderAll() {
  updateHeader();
  renderInventory();
  renderMarketplace();
  renderCart();
}

function fillFormsForTenant() {
  const defaults = tenantDefaults[state.activeTenant];
  const password = "Password123!";

  $("tenantSignupForm").elements.tenant_name.value = defaults.tenant_name;
  $("tenantSignupForm").elements.tenant_slug.value = defaults.tenant_slug;
  $("tenantSignupForm").elements.seller_name.value = defaults.seller_name;
  $("tenantSignupForm").elements.seller_email.value = defaults.seller_email;
  $("tenantSignupForm").elements.password.value = password;

  $("sellerLoginForm").elements.tenant_slug.value = defaults.tenant_slug;
  $("sellerLoginForm").elements.username.value = defaults.seller_email;
  $("sellerLoginForm").elements.password.value = password;

  $("customerSignupForm").elements.tenant_slug.value = defaults.tenant_slug;
  $("customerSignupForm").elements.full_name.value = defaults.customer_name;
  $("customerSignupForm").elements.email.value = defaults.customer_email;
  $("customerSignupForm").elements.password.value = password;

  $("customerLoginForm").elements.tenant_slug.value = defaults.tenant_slug;
  $("customerLoginForm").elements.username.value = defaults.customer_email;
  $("customerLoginForm").elements.password.value = password;
}

function loadTenantState() {
  state.sellerToken = localStorage.getItem(storageKey("sellerToken")) || "";
  state.customerToken = localStorage.getItem(storageKey("customerToken")) || "";
  $("sellerToken").value = state.sellerToken;
  $("customerToken").value = state.customerToken;
}

function switchTenant(tenant) {
  state.activeTenant = tenant;
  state.products = [];
  state.cart = [];
  state.search = "";
  $("tenantSelect").value = tenant;
  $("searchInput").value = "";
  fillFormsForTenant();
  loadTenantState();
  renderAll();
}

async function handleTenantSignup(event) {
  event.preventDefault();
  const payload = formJson(event.currentTarget);
  const data = await request(`${baseUrls().tenant}/tenants/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  log("Tenant created", data);
}

async function handleCustomerSignup(event) {
  event.preventDefault();
  const payload = formJson(event.currentTarget);
  const data = await request(`${baseUrls().tenant}/customers/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  log("Customer created", data);
}

async function login(form, tokenKind, label) {
  const payload = new URLSearchParams(formJson(form));
  const data = await request(`${baseUrls().tenant}/auth/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: payload,
  });
  setToken(tokenKind, data.access_token);
  log(`${label} logged in`, data);
  renderAll();
}

async function loadProfile(token, label) {
  const data = await request(`${baseUrls().tenant}/auth/me`, {
    headers: authHeaders(token),
  });
  log(`${label} profile`, data);
}

async function createProduct(event) {
  event.preventDefault();
  if (!state.sellerToken) {
    throw new Error("Seller login required before creating products.");
  }
  const payload = formJson(event.currentTarget);
  payload.price = Number(payload.price);
  payload.stock = Number(payload.stock);
  const data = await request(`${baseUrls().product}/products`, {
    method: "POST",
    headers: {
      ...authHeaders(state.sellerToken),
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  log("Product created", data);
  await loadProducts();
}

async function loadProducts() {
  const token = state.sellerToken || state.customerToken;
  if (!token) {
    state.products = [];
    renderAll();
    log("Products not loaded", "Log in as seller or customer for the active tenant first.");
    return;
  }
  const data = await request(`${baseUrls().product}/products`, {
    headers: authHeaders(token),
  });
  state.products = data.items || [];
  renderAll();
  log("Products loaded", data);
}

async function addToCartById(productId) {
  if (!state.customerToken) {
    throw new Error("Customer login required before adding to cart.");
  }

  const data = await request(`${baseUrls().order}/cart/add`, {
    method: "POST",
    headers: {
      ...authHeaders(state.customerToken),
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ product_id: productId, quantity: 1 }),
  });
  log("Cart updated", data);
  await loadCart();
}

async function loadCart() {
  if (!state.customerToken) {
    state.cart = [];
    renderAll();
    log("Cart not loaded", "Customer login required for the active tenant.");
    return;
  }
  const data = await request(`${baseUrls().order}/cart`, {
    headers: authHeaders(state.customerToken),
  });
  state.cart = data.items || [];
  renderCart();
  log("Cart loaded", data);
}

async function checkout() {
  if (!state.customerToken) {
    throw new Error("Customer login required before checkout.");
  }
  const data = await request(`${baseUrls().order}/orders/checkout`, {
    method: "POST",
    headers: authHeaders(state.customerToken),
  });
  state.cart = [];
  renderAll();
  $("orderOutput").textContent = JSON.stringify(data, null, 2);
  log("Checkout complete", data);
}

async function editProduct(productId) {
  if (!state.sellerToken) {
    throw new Error("Seller login required before editing products.");
  }
  const product = state.products.find((item) => Number(item.id) === productId);
  if (!product) {
    return;
  }

  const name = window.prompt("Product name", product.name);
  if (name === null) {
    return;
  }
  const price = window.prompt("Price", product.price);
  if (price === null) {
    return;
  }
  const stock = window.prompt("Stock", product.stock);
  if (stock === null) {
    return;
  }

  const data = await request(`${baseUrls().product}/products/${productId}`, {
    method: "PATCH",
    headers: {
      ...authHeaders(state.sellerToken),
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name, price: Number(price), stock: Number(stock) }),
  });
  log("Product updated", data);
  await loadProducts();
}

async function deleteProduct(productId) {
  if (!state.sellerToken) {
    throw new Error("Seller login required before deleting products.");
  }
  if (!window.confirm("Delete this product?")) {
    return;
  }
  const data = await request(`${baseUrls().product}/products/${productId}`, {
    method: "DELETE",
    headers: authHeaders(state.sellerToken),
  });
  log("Product deleted", data);
  await loadProducts();
}

function clearConsole() {
  $("logOutput").textContent = "Ready.";
  $("orderOutput").textContent = "Checkout response will appear here.";
}

function setActiveTab(tab) {
  const sellerActive = tab === "seller";
  $("sellerTab").classList.toggle("is-active", sellerActive);
  $("marketTab").classList.toggle("is-active", !sellerActive);
  $("sellerView").classList.toggle("is-active", sellerActive);
  $("marketView").classList.toggle("is-active", !sellerActive);
}

function bind() {
  $("tenantSelect").addEventListener("change", async (event) => {
    switchTenant(event.currentTarget.value);
    await loadProducts().catch(() => {});
    await loadCart().catch(() => {});
  });
  $("sellerTab").addEventListener("click", () => setActiveTab("seller"));
  $("marketTab").addEventListener("click", () => setActiveTab("market"));
  $("searchInput").addEventListener("input", (event) => {
    state.search = event.currentTarget.value;
    renderMarketplace();
  });
  $("tenantSignupForm").addEventListener("submit", async (event) => {
    try {
      await handleTenantSignup(event);
    } catch (error) {
      log("Tenant signup failed", error.message);
    }
  });
  $("sellerLoginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await login(event.currentTarget, "sellerToken", "Seller");
      await loadProducts();
    } catch (error) {
      log("Seller login failed", error.message);
    }
  });
  $("customerSignupForm").addEventListener("submit", async (event) => {
    try {
      await handleCustomerSignup(event);
    } catch (error) {
      log("Customer signup failed", error.message);
    }
  });
  $("customerLoginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await login(event.currentTarget, "customerToken", "Customer");
      await loadProducts();
      await loadCart();
    } catch (error) {
      log("Customer login failed", error.message);
    }
  });
  $("productForm").addEventListener("submit", async (event) => {
    try {
      await createProduct(event);
    } catch (error) {
      log("Product create failed", error.message);
    }
  });
  $("sellerRefresh").addEventListener("click", () =>
    loadProducts().catch((error) => log("Seller refresh failed", error.message))
  );
  $("marketRefresh").addEventListener("click", () =>
    loadProducts().catch((error) => log("Market refresh failed", error.message))
  );
  $("loadCart").addEventListener("click", () => loadCart().catch((error) => log("Load cart failed", error.message)));
  $("checkoutBtn").addEventListener("click", () => checkout().catch((error) => log("Checkout failed", error.message)));
  $("clearOutput").addEventListener("click", clearConsole);
  $("sellerToken").addEventListener("change", (event) => setToken("sellerToken", event.currentTarget.value.trim()));
  $("customerToken").addEventListener("change", (event) => setToken("customerToken", event.currentTarget.value.trim()));
}

bind();
switchTenant(state.activeTenant);
setActiveTab("seller");
renderAll();
